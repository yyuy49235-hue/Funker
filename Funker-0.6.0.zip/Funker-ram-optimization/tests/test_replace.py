import json, os, shutil, sys, tempfile, unittest, zipfile, errno
from unittest import mock
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "app", "src", "main", "python"))
from PIL import Image
from funkerlitelab import engine, library, replace


def make_mod(path, extra=None):
    os.makedirs(os.path.join(path, "images"), exist_ok=True)
    Image.new("RGBA", (64, 64), (200, 50, 50, 255)).save(os.path.join(path, "images", "a.png"))
    with open(os.path.join(path, "pack.json"), "w") as f:
        json.dump({"name": "T"}, f)
    for rel, data in (extra or {}).items():
        os.makedirs(os.path.dirname(os.path.join(path, rel)), exist_ok=True)
        with open(os.path.join(path, rel), "wb") as f:
            f.write(data)


def zip_dir(src, dst):
    with zipfile.ZipFile(dst, "w") as z:
        for dp, _, fn in os.walk(src):
            for f in fn:
                p = os.path.join(dp, f)
                z.write(p, os.path.relpath(p, src))


class Base(unittest.TestCase):
    def setUp(self):
        self.t = tempfile.mkdtemp()
        self.mods = os.path.join(self.t, "mods"); os.makedirs(self.mods)
        self.dl = os.path.join(self.t, "Download"); os.makedirs(self.dl)
        self.work = os.path.join(self.t, "cache"); os.makedirs(self.work)

    def tearDown(self):
        shutil.rmtree(self.t, ignore_errors=True)

    def run_replace(self, path, **kw):
        return replace.optimize_and_replace(path, "light", self.dl, work_dir=self.work, **kw)

    def leftovers(self):
        return [n for n in os.listdir(self.mods) if n.endswith(".flab-part")] + os.listdir(self.work)


class TestDiscovery(Base):
    def test_lists_folders_and_zips_with_status(self):
        make_mod(os.path.join(self.mods, "Tabi"))
        make_mod(os.path.join(self.mods, "Tabi_opt"))
        make_mod(os.path.join(self.mods, "Other"))
        zip_dir(os.path.join(self.mods, "Other"), os.path.join(self.mods, "Zipped.zip"))
        os.makedirs(os.path.join(self.mods, "random_folder")); open(os.path.join(self.mods, "random_folder", "x.txt"), "w").close()
        open(os.path.join(self.mods, "modsList.txt"), "w").close()
        open(os.path.join(self.mods, "old.rar"), "w").close()
        os.makedirs(os.path.join(self.mods, ".hidden"))
        r = library.discover([self.mods], self.dl)["roots"][0]
        by = {m["name"]: m for m in r["mods"]}
        self.assertEqual(r["state"], "ok")
        self.assertNotIn("modsList.txt", by); self.assertNotIn(".hidden", by)
        self.assertEqual(by["Tabi"]["status"], "has_optimized")
        self.assertEqual(by["Tabi_opt"]["status"], "optimized")
        self.assertEqual(by["Other"]["status"], "original")
        self.assertEqual(by["Zipped.zip"]["kind"], "zip"); self.assertTrue(by["Zipped.zip"]["supported"])
        self.assertFalse(by["random_folder"]["supported"]); self.assertIn("mod", by["random_folder"]["note"])
        self.assertFalse(by["old.rar"]["supported"])

    def test_missing_and_unreadable_roots_are_reported(self):
        miss = os.path.join(self.t, "nope")
        f = os.path.join(self.t, "afile"); open(f, "w").close()
        d = library.discover([miss, f, miss])  # duplicate root listed once
        self.assertEqual([r["state"] for r in d["roots"]], ["missing", "not_a_folder"])
        with mock.patch("os.listdir", side_effect=PermissionError):
            self.assertEqual(library.scan_root(self.mods)["state"], "no_permission")

    def test_backup_flag(self):
        make_mod(os.path.join(self.mods, "Tabi")); make_mod(os.path.join(self.dl, "Tabi"))
        m = library.scan_root(self.mods, self.dl)["mods"][0]
        self.assertTrue(m["backup_in_downloads"])

    def test_opt_names(self):
        for n in ("Tabi_opt", "Tabi_opt2", "Tabi_opt.zip", "Tabi_opt12.zip"):
            self.assertTrue(library.is_opt_name(n), n)
        for n in ("Tabi", "optical", "Tabi_optimized", "opt"):
            self.assertFalse(library.is_opt_name(n), n)


class TestReplaceFolder(Base):
    def test_success_folder(self):
        orig = os.path.join(self.mods, "Tabi"); make_mod(orig, {"scripts/a.lua": b"print(1)"})
        before = replace.tree_digest(orig)
        r = self.run_replace(orig)
        self.assertTrue(r["ok"] and r["optimization_ok"] and r["validation_ok"] and r["replacement_ok"], r["error"])
        self.assertEqual(r["final_path"], os.path.join(self.mods, "Tabi_opt"))
        self.assertTrue(os.path.isdir(r["final_path"]))
        self.assertFalse(os.path.exists(orig))
        self.assertEqual(r["backup_path"], os.path.join(self.dl, "Tabi"))
        self.assertEqual(replace.tree_digest(r["backup_path"]), before)  # original preserved byte for byte
        self.assertEqual(self.leftovers(), [])

    def test_success_zip_keeps_zip(self):
        src = os.path.join(self.t, "src"); make_mod(src)
        zip_dir(src, os.path.join(self.mods, "Tabi.zip"))
        r = self.run_replace(os.path.join(self.mods, "Tabi.zip"))
        self.assertTrue(r["ok"], r["error"])
        self.assertEqual(r["final_path"], os.path.join(self.mods, "Tabi_opt.zip"))
        self.assertTrue(zipfile.is_zipfile(r["final_path"]))
        self.assertTrue(os.path.isfile(os.path.join(self.dl, "Tabi.zip")))
        self.assertEqual(self.leftovers(), [])

    def test_output_zip_option_for_folder_mod(self):
        orig = os.path.join(self.mods, "Tabi"); make_mod(orig)
        r = self.run_replace(orig, output="zip")
        self.assertTrue(r["ok"], r["error"]); self.assertTrue(r["final_path"].endswith("Tabi_opt.zip"))

    def test_existing_optimized_name_is_not_overwritten(self):
        orig = os.path.join(self.mods, "Tabi"); make_mod(orig)
        old_opt = os.path.join(self.mods, "Tabi_opt"); make_mod(old_opt, {"marker.txt": b"keep me"})
        d = replace.tree_digest(old_opt)
        r = self.run_replace(orig)
        self.assertTrue(r["ok"], r["error"])
        self.assertTrue(r["renamed_for_collision"])
        self.assertEqual(r["final_path"], os.path.join(self.mods, "Tabi_opt2"))
        self.assertEqual(replace.tree_digest(old_opt), d)

    def test_existing_backup_is_not_overwritten(self):
        orig = os.path.join(self.mods, "Tabi"); make_mod(orig)
        old_bk = os.path.join(self.dl, "Tabi"); make_mod(old_bk, {"marker.txt": b"older backup"})
        d = replace.tree_digest(old_bk)
        r = self.run_replace(orig)
        self.assertTrue(r["ok"], r["error"])
        self.assertEqual(r["backup_path"], os.path.join(self.dl, "Tabi_original"))
        self.assertEqual(replace.tree_digest(old_bk), d)

    def test_validation_failure_leaves_original_untouched(self):
        orig = os.path.join(self.mods, "Tabi"); make_mod(orig)
        before = replace.tree_digest(orig)
        with mock.patch.object(replace, "validate_output", return_value=["forced problem"]):
            r = self.run_replace(orig)
        self.assertFalse(r["ok"]); self.assertTrue(r["optimization_ok"]); self.assertFalse(r["validation_ok"])
        self.assertFalse(r["replacement_ok"]); self.assertEqual(r["stage_failed"], "validate")
        self.assertEqual(replace.tree_digest(orig), before)
        self.assertEqual(os.listdir(self.dl), []); self.assertEqual(self.leftovers(), [])
        self.assertEqual(os.listdir(self.mods), ["Tabi"])

    def test_optimizer_failure_leaves_original_untouched(self):
        orig = os.path.join(self.mods, "Tabi"); make_mod(orig); before = replace.tree_digest(orig)
        with mock.patch.object(engine, "optimize_mod", return_value={"ok": False, "problems": ["boom"]}):
            r = self.run_replace(orig)
        self.assertFalse(r["optimization_ok"]); self.assertEqual(r["stage_failed"], "optimize")
        self.assertEqual(replace.tree_digest(orig), before); self.assertEqual(self.leftovers(), [])

    def test_backup_failure_rolls_back_cleanly(self):
        orig = os.path.join(self.mods, "Tabi"); make_mod(orig); before = replace.tree_digest(orig)
        with mock.patch.object(replace, "safe_move", side_effect=OSError("disk full")):
            r = self.run_replace(orig)
        self.assertFalse(r["ok"]); self.assertEqual(r["stage_failed"], "backup")
        self.assertEqual(replace.tree_digest(orig), before)
        self.assertEqual(os.listdir(self.mods), ["Tabi"]); self.assertEqual(self.leftovers(), [])

    def test_place_failure_restores_original(self):
        orig = os.path.join(self.mods, "Tabi"); make_mod(orig); before = replace.tree_digest(orig)
        real_rename = os.rename
        def flaky(a, b):
            if str(a).endswith(".flab-part"):
                raise OSError("rename refused")
            return real_rename(a, b)
        with mock.patch("os.rename", side_effect=flaky):
            r = self.run_replace(orig)
        self.assertFalse(r["replacement_ok"]); self.assertEqual(r["stage_failed"], "place")
        self.assertTrue(r["rolled_back"])
        self.assertEqual(replace.tree_digest(orig), before)  # original is back, byte for byte
        self.assertEqual(os.listdir(self.dl), []); self.assertEqual(self.leftovers(), [])

    def test_cross_device_move_falls_back_to_verified_copy(self):
        orig = os.path.join(self.mods, "Tabi"); make_mod(orig); before = replace.tree_digest(orig)
        real_rename = os.rename
        def exdev(a, b):
            if os.path.abspath(a) == orig:
                raise OSError(errno.EXDEV, "Invalid cross-device link")
            return real_rename(a, b)
        with mock.patch("os.rename", side_effect=exdev):
            r = self.run_replace(orig)
        self.assertTrue(r["ok"], r["error"])
        self.assertEqual(replace.tree_digest(r["backup_path"]), before)
        self.assertFalse(os.path.exists(orig))

    def test_failed_delete_after_copy_restores_original(self):
        src = os.path.join(self.t, "a"); make_mod(src); before = replace.tree_digest(src)
        dst = os.path.join(self.t, "b")
        real_rename, real_rmtree = os.rename, shutil.rmtree

        def rename(a, b):
            if a == src:
                raise OSError(errno.EXDEV, "Invalid cross-device link")
            return real_rename(a, b)

        def rmtree(p, *a, **k):
            if p == src:  # delete fails half way: one file is already gone
                os.remove(os.path.join(p, "pack.json"))
                raise OSError("denied")
            return real_rmtree(p, *a, **k)

        with mock.patch("os.rename", side_effect=rename), mock.patch("shutil.rmtree", side_effect=rmtree):
            with self.assertRaises(OSError) as cm:
                replace.safe_move(src, dst)
        self.assertIn("original restored", str(cm.exception))
        self.assertEqual(replace.tree_digest(src), before)
        self.assertFalse(os.path.exists(dst))

    def test_already_optimized_is_refused(self):
        orig = os.path.join(self.mods, "Tabi_opt"); make_mod(orig); before = replace.tree_digest(orig)
        r = self.run_replace(orig)
        self.assertFalse(r["ok"]); self.assertEqual(r["stage_failed"], "input"); self.assertEqual(replace.tree_digest(orig), before)

    def test_missing_backup_folder_changes_nothing(self):
        orig = os.path.join(self.mods, "Tabi"); make_mod(orig); before = replace.tree_digest(orig)
        r = replace.optimize_and_replace(orig, "light", os.path.join(self.t, "nodl"), work_dir=self.work)
        self.assertEqual(r["stage_failed"], "backup-folder"); self.assertEqual(replace.tree_digest(orig), before)

    def test_zip_slip_is_rejected(self):
        z = os.path.join(self.mods, "Bad.zip")
        with zipfile.ZipFile(z, "w") as zf:
            zf.writestr("../evil.txt", "x"); zf.writestr("pack.json", "{}")
        r = self.run_replace(z)
        self.assertFalse(r["ok"]); self.assertFalse(os.path.exists(os.path.join(self.mods, "..", "evil.txt")))
        self.assertTrue(os.path.exists(z))

    def test_validator_catches_a_damaged_output(self):
        orig = os.path.join(self.t, "m"); make_mod(orig)
        out = os.path.join(self.t, "o.zip"); engine.optimize_mod(orig, out, "light")
        self.assertEqual(replace.validate_output(orig, out), [])
        with zipfile.ZipFile(out, "a") as zf:
            zf.writestr("extra.bin", b"1")
        self.assertTrue(any("extra file" in p for p in replace.validate_output(orig, out)))

    def test_cancel_before_commit_changes_nothing(self):
        orig = os.path.join(self.mods, "Tabi"); make_mod(orig); before = replace.tree_digest(orig)
        def cb(stage, d, t, n):
            if stage == "Packaging":
                raise engine.Cancelled()
            return True
        r = self.run_replace(orig, progress=cb)
        self.assertEqual(r["stage_failed"], "cancelled"); self.assertEqual(replace.tree_digest(orig), before)
        self.assertEqual(self.leftovers(), [])


if __name__ == "__main__":
    unittest.main()
