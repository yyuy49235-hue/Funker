"""Every theme combination the Appearance screen can produce must be readable (WCAG 2.x contrast)."""
import itertools, json, os, unittest

PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "app", "src", "main", "assets", "themes.json")
T = json.load(open(PATH))


def rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def lum(c):
    def f(v):
        v /= 255.0
        return v / 12.92 if v <= 0.03928 else ((v + 0.055) / 1.055) ** 2.4
    r, g, b = (f(x) for x in c)
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def ratio(a, b):
    la, lb = lum(a), lum(b)
    hi, lo = max(la, lb), min(la, lb)
    return (hi + 0.05) / (lo + 0.05)


def blend(fg, bg, a):
    return tuple(round(fg[i] * a + bg[i] * (1 - a)) for i in range(3))


def combos():
    for p, mode, g, bgs in itertools.product(T["presets"], ("night", "day"), T["gold"], T["background"]):
        base = dict(T["presets"][p][mode])
        if bgs != "preset":
            base.update(T["background"][bgs][mode])
        yield "%s/%s/%s/%s" % (p, mode, g, bgs), base, T["gold"][g][mode], T["status"][mode]


class TestThemes(unittest.TestCase):
    def test_defaults_exist(self):
        d = T["defaults"]
        self.assertIn(d["preset"], T["presets"]); self.assertIn(d["gold"], T["gold"])
        self.assertIn(d["background"], T["background"]); self.assertIn(d["density"], T["density"])
        self.assertIn(d["corners"], T["corners"]); self.assertIn(d["cards"], T["cards"])
        self.assertIn(d["buttons"], T["buttons"]); self.assertIn(d["mode"], T["modes"])

    def test_text_is_readable_everywhere(self):
        for name, b, g, s in combos():
            for surf in ("bg", "surface", "surface2"):
                self.assertGreaterEqual(ratio(rgb(b["text"]), rgb(b[surf])), 7.0, name + " text on " + surf)
                self.assertGreaterEqual(ratio(rgb(b["muted"]), rgb(b[surf])), 4.5, name + " muted on " + surf)

    def test_gold_text_is_readable_everywhere(self):
        for name, b, g, s in combos():
            for surf in ("bg", "surface", "surface2"):
                self.assertGreaterEqual(ratio(rgb(g["text"]), rgb(b[surf])), 4.5, name + " gold text on " + surf)

    def test_filled_button_label_and_edges(self):
        for name, b, g, s in combos():
            self.assertGreaterEqual(ratio(rgb(g["onFill"]), rgb(g["fill"])), 4.5, name + " label on gold")
            for surf in ("bg", "surface"):
                self.assertGreaterEqual(ratio(rgb(g["fill"]), rgb(b[surf])), 3.0, name + " gold vs " + surf)

    def test_soft_button_label(self):
        a = T["soft_alpha"]
        for name, b, g, s in combos():
            for surf in ("surface", "surface2"):
                bg = blend(rgb(g["fill"]), rgb(b[surf]), a)
                self.assertGreaterEqual(ratio(rgb(g["text"]), bg), 4.5, name + " soft button on " + surf)

    def test_status_colors_readable(self):
        for name, b, g, s in combos():
            for k, v in s.items():
                for surf in ("surface", "surface2"):
                    self.assertGreaterEqual(ratio(rgb(v), rgb(b[surf])), 4.5, "%s status %s on %s" % (name, k, surf))

    def test_surfaces_are_distinguishable_from_outline(self):
        for p in T["presets"].values():
            for mode in ("night", "day"):
                self.assertGreaterEqual(ratio(rgb(p[mode]["outline"]), rgb(p[mode]["surface"])), 1.15)

    def test_counts_match_what_the_screen_offers(self):
        self.assertEqual(len(list(combos())), len(T["presets"]) * 2 * len(T["gold"]) * len(T["background"]))
        self.assertGreaterEqual(len(T["presets"]), 4); self.assertGreaterEqual(len(T["gold"]), 5)


if __name__ == "__main__":
    unittest.main()
