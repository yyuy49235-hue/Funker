import json, os, sys, tempfile, unittest
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "app", "src", "main", "python"))
import bridge


class Sink:
    def __init__(self, stop_at=None):
        self.calls, self.stop_at = [], stop_at

    def update(self, stage, done, total, name):
        self.calls.append(stage)
        return stage != self.stop_at


class TestBridge(unittest.TestCase):
    def setUp(self):
        self.t = tempfile.mkdtemp()
        os.makedirs(os.path.join(self.t, "m"))
        open(os.path.join(self.t, "m", "a.txt"), "w").write("hi")

    def test_ok_and_progress(self):
        s = Sink()
        r = json.loads(bridge.run(os.path.join(self.t, "m"), os.path.join(self.t, "o.zip"), "light", s))
        self.assertTrue(r["ok"])
        self.assertIn("Packaging", s.calls)

    def test_cancel(self):
        r = json.loads(bridge.run(os.path.join(self.t, "m"), os.path.join(self.t, "o.zip"), "light", Sink("Packaging")))
        self.assertFalse(r["ok"]); self.assertTrue(r["cancelled"])

    def test_error_is_reported_not_raised(self):
        r = json.loads(bridge.run("/nonexistent", os.path.join(self.t, "o.zip"), "light", Sink()))
        self.assertFalse(r["ok"]); self.assertIn("error", r)

    def test_options_are_filtered_and_applied(self):
        r = json.loads(bridge.run(os.path.join(self.t, "m"), os.path.join(self.t, "o.zip"), "light", Sink(),
                                  json.dumps({"fps": False, "dedupe": False, "evil": "rm -rf"})))
        self.assertTrue(r["ok"]); self.assertEqual(r["options"]["fps"], False); self.assertEqual(r["options"]["dedupe"], False)

    def test_discover_and_replace_roundtrip(self):
        mods = os.path.join(self.t, "mods"); dl = os.path.join(self.t, "dl"); os.makedirs(os.path.join(mods, "M", "images")); os.makedirs(dl)
        open(os.path.join(mods, "M", "pack.json"), "w").write("{}")
        d = json.loads(bridge.discover(json.dumps([mods]), dl))
        self.assertEqual(d["total"], 1)
        r = json.loads(bridge.run_replace(os.path.join(mods, "M"), "light", dl, self.t, "{}", "auto", Sink()))
        self.assertTrue(r["replacement_ok"], r)
        self.assertTrue(os.path.isdir(os.path.join(mods, "M_opt")))

    def test_replace_error_is_reported_not_raised(self):
        r = json.loads(bridge.run_replace("/nonexistent/x", "light", self.t, self.t, "{}", "auto", Sink()))
        self.assertFalse(r["ok"]); self.assertIn("error", r)


if __name__ == "__main__":
    unittest.main()
