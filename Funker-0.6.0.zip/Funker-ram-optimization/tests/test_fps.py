import io, os, sys, zipfile, xml.etree.ElementTree as ET
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from test_repack import RepackBase, frames_rendered, unittest
from PIL import Image
from funkerlitelab import engine, fps_opt

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
REAL = os.path.join(ROOT, "legacy", "test_run", "images", "agoti", "images")


def rects(xml_bytes):
    return {(e.get("x"), e.get("y"), e.get("width"), e.get("height")) for e in ET.fromstring(xml_bytes).iter("SubTexture")}


class TestFpsSwitches(RepackBase):
    def setUp(self):
        super().setUp()
        self.im, self.xml = self.atlas("images/stages/prop.png", name="prop", W=2048, H=2048, fw=256, fh=256, n=40)
        self.old_png = open(os.path.join(self.mod, "images/stages/prop.png"), "rb").read()

    def build(self, **kw):
        z = os.path.join(self.out, "o%d.zip" % len(os.listdir(self.out)))
        rep = engine.optimize_mod(self.mod, z, "light", **kw)
        with zipfile.ZipFile(z) as zf:
            return rep, zf.read("images/stages/prop.png"), zf.read("images/stages/prop.xml")

    def same_render(self, png, xml):
        a, b = frames_rendered(self.old_png, self.xml.encode()), frames_rendered(png, xml)
        self.assertEqual(a.keys(), b.keys())
        for k in a:
            self.assertTrue(a[k] == b[k], "frame %s renders differently" % k)

    def test_trim_on_shrinks_drawn_area_and_renders_identically(self):
        rep, png, xml = self.build(repack=True, max_dim=None, fps=True)
        f = rep["fps"]
        self.assertTrue(f["enabled"]); self.assertEqual(f["trimmed_atlases"], 1)
        self.assertLess(f["drawn_area_after"], f["drawn_area_before"])
        self.assertGreater(f["drawn_area_cut_percent"], 10)
        self.same_render(png, xml)

    def test_trim_off_keeps_every_frame_rectangle_size(self):
        rep, png, xml = self.build(repack=True, max_dim=None, fps=False)
        self.assertEqual(rep["fps"], {"enabled": False})
        for e in ET.fromstring(xml).iter("SubTexture"):
            self.assertEqual((e.get("width"), e.get("height")), ("256", "256"))
        self.same_render(png, xml)

    def test_dedupe_switch(self):
        _, _, x_on = self.build(repack=True, max_dim=None, dedupe=True)
        _, _, x_off = self.build(repack=True, max_dim=None, dedupe=False)
        self.assertLess(len(rects(x_on)), len(rects(x_off)))

    def test_all_switches_off_changes_nothing_structural(self):
        rep, png, xml = self.build(repack=False, max_dim=None, dedupe=False, fps=False)
        self.assertEqual(rep["repacked"], 0)
        self.assertEqual(Image.open(io.BytesIO(png)).size, (2048, 2048))

    def test_options_reported(self):
        rep, _, _ = self.build(repack=True, max_dim=None, dedupe=False, fps=True)
        self.assertEqual(rep["options"], {"repack": True, "max_dim": None, "dedupe": False, "fps": True})

    def test_level_defaults_unchanged(self):
        z = os.path.join(self.out, "d.zip")
        rep = engine.optimize_mod(self.mod, z, "maximum")
        self.assertEqual(rep["options"]["repack"], True)
        self.assertEqual(rep["options"]["max_dim"], 1024)
        self.assertEqual(rep["repacked"], 1)

    def test_risk_report_flags_huge_textures(self):
        self.put("images/bg_wide.png", Image.new("RGBA", (4400, 40), (0, 0, 0, 255)))
        rep, _, _ = self.build(repack=False, max_dim=None)
        risky = {r["file"] for r in rep["fps"]["frame_time_risks"]}
        self.assertIn("images/bg_wide.png", risky)
        self.assertNotIn("images/stages/prop.png", risky)

    def test_build_report_disabled(self):
        self.assertEqual(fps_opt.build_report(False, {}, {}, 0, 0, 0), {"enabled": False})


@unittest.skipUnless(os.path.exists(os.path.join(REAL, "Agoti_Cutscene_A.png")), "real atlas not in this checkout")
class TestRealAtlas(RepackBase):
    """A real atlas shipped in legacy/test_run (104 frames). Static check only, not a game test."""
    def test_real_atlas_renders_identically_and_uses_less(self):
        png = open(os.path.join(REAL, "Agoti_Cutscene_A.png"), "rb").read()
        xml = open(os.path.join(REAL, "Agoti_Cutscene_A.xml"), "rb").read()
        self.put("images/agoti/Agoti_Cutscene_A.png", png)
        self.put("images/agoti/Agoti_Cutscene_A.xml", xml)
        z = os.path.join(self.out, "r.zip")
        rep = engine.optimize_mod(self.mod, z, "strong")
        self.assertTrue(rep["ok"]); self.assertEqual(rep["repacked"], 1)
        with zipfile.ZipFile(z) as zf:
            new_png, new_xml = zf.read("images/agoti/Agoti_Cutscene_A.png"), zf.read("images/agoti/Agoti_Cutscene_A.xml")
        a, b = frames_rendered(png, xml), frames_rendered(new_png, new_xml)
        self.assertEqual(a.keys(), b.keys())
        for k in a:
            self.assertTrue(a[k] == b[k], "frame %s renders differently" % k)
        self.assertLess(rep["texture_bytes_after"], 0.5 * rep["texture_bytes_before"])
        self.assertGreater(rep["fps"]["drawn_area_cut_percent"], 40)


if __name__ == "__main__":
    unittest.main()
