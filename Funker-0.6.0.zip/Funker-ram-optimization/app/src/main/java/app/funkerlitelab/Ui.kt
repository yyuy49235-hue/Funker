package app.funkerlitelab

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.RadioButton
import android.widget.Switch
import android.widget.TextView

/** Small view factory. Every colour, radius and spacing comes from the Palette, so all screens match. */
class Ui(val ctx: Context, val p: Palette) {
    fun dp(v: Int): Int = (v * p.space * ctx.resources.displayMetrics.density).toInt()
    /** Fixed size (icons, borders) that must not follow the density setting. */
    fun px(v: Int): Int = (v * ctx.resources.displayMetrics.density).toInt()

    fun shape(color: Int, radius: Int, stroke: Int = 0): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = px(radius).toFloat()
        if (stroke != 0) setStroke(px(1), stroke)
    }

    fun lp(top: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(top) }

    fun card(topMargin: Int = 12): LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        when (p.cards) {
            "flat" -> background = shape(p.surface2, p.rCard)
            "elevated" -> {
                if (p.shadows) { background = shape(p.surface, p.rCard); elevation = px(4).toFloat() }
                else background = shape(p.surface, p.rCard, p.outline)  // no shadows: soft outline instead
            }
            else -> background = shape(p.surface, p.rCard, p.outline)
        }
        setPadding(dp(16), dp(14), dp(16), dp(16))
        layoutParams = lp(topMargin)
    }

    fun title(t: String, size: Float = 26f) = TextView(ctx).apply {
        text = t; setTextColor(p.text); textSize = size; typeface = Typeface.DEFAULT_BOLD
    }

    fun heading(t: String) = TextView(ctx).apply {
        text = t; setTextColor(p.text); textSize = 16f; typeface = Typeface.DEFAULT_BOLD
    }

    fun body(t: String, color: Int = p.muted, size: Float = 13f) = TextView(ctx).apply {
        text = t; setTextColor(color); textSize = size; setPadding(0, dp(6), 0, 0)
    }

    fun sectionLabel(t: String) = TextView(ctx).apply {
        text = t.uppercase(); setTextColor(p.goldText); textSize = 11f; typeface = Typeface.DEFAULT_BOLD
        letterSpacing = 0.08f; setPadding(0, dp(14), 0, dp(4))
    }

    fun button(label: String, primary: Boolean = true, topMargin: Int = 10): Button = Button(ctx).apply {
        text = label; isAllCaps = false; textSize = 15f; stateListAnimator = null
        minimumHeight = px(48)
        val r = p.rButton
        when {
            primary && p.buttons == "filled" -> {
                background = shape(p.fill, r); setTextColor(p.onFill)
                if (p.shadows) elevation = px(2).toFloat()
            }
            primary && p.buttons == "soft" -> { background = shape(p.softFill, r); setTextColor(p.goldText) }
            else -> { background = shape(Color.TRANSPARENT, r, p.fill); setTextColor(p.goldText) }
        }
        layoutParams = lp(topMargin)
    }

    fun setEnabledLook(v: View, enabled: Boolean) { v.isEnabled = enabled; v.alpha = if (enabled) 1f else 0.45f }

    fun chip(label: String, color: Int) = TextView(ctx).apply {
        text = label; textSize = 11f; setTextColor(color); typeface = Typeface.DEFAULT_BOLD
        background = shape(p.surface2, 20, color)
        setPadding(px(10), px(3), px(10), px(3))
    }

    fun field(hint: String): EditText = EditText(ctx).apply {
        this.hint = hint; setHintTextColor(p.muted); setTextColor(p.text); textSize = 14f
        setSingleLine(true)
        background = shape(p.surface2, p.rField, p.outline)
        setPadding(px(12), px(10), px(12), px(10))
        layoutParams = lp(6)
    }

    fun radio(id: Int, label: String): RadioButton = RadioButton(ctx).apply {
        this.id = id; text = label; setTextColor(p.text); textSize = 14f
        setPadding(px(8), dp(8), px(4), dp(8))
        buttonTintList = ColorStateList.valueOf(p.fill)
    }

    fun switchRow(label: String, hint: String, checked: Boolean, onChange: (Boolean) -> Unit): LinearLayout =
        LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(6), 0, dp(6))
            val texts = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                addView(TextView(ctx).apply { text = label; setTextColor(p.text); textSize = 14f })
                if (hint.isNotEmpty()) addView(TextView(ctx).apply { text = hint; setTextColor(p.muted); textSize = 12f })
            }
            val sw = Switch(ctx).apply {
                isChecked = checked
                thumbTintList = ColorStateList.valueOf(if (checked) p.fill else p.muted)
                trackTintList = ColorStateList.valueOf(if (checked) p.softFill else p.outline)
                setOnCheckedChangeListener { v, on ->
                    (v as Switch).thumbTintList = ColorStateList.valueOf(if (on) p.fill else p.muted)
                    v.trackTintList = ColorStateList.valueOf(if (on) p.softFill else p.outline)
                    onChange(on)
                }
            }
            addView(texts); addView(sw)
        }

    fun progress(): ProgressBar = ProgressBar(ctx, null, android.R.attr.progressBarStyleHorizontal).apply {
        isIndeterminate = true
        progressTintList = ColorStateList.valueOf(p.fill)
        progressBackgroundTintList = ColorStateList.valueOf(p.outline)
        indeterminateTintList = ColorStateList.valueOf(p.fill)
        layoutParams = lp(10)
    }

    /** Header bar: flat, or a gradient from surface2 to the page colour when "gradient" is on. */
    fun header(): LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        background = if (p.gradient)
            GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(p.surface2, p.bg)).apply { cornerRadius = px(p.rCard).toFloat() }
        else shape(p.bg, p.rCard)
        setPadding(dp(16), dp(16), dp(16), dp(14))
        layoutParams = lp(0)
    }

    /** Short fade-in, only when animations are on. Costs nothing when off. */
    fun appear(v: View) {
        if (!p.animations) return
        v.alpha = 0f
        v.animate().alpha(1f).setDuration(180).start()
    }
}
