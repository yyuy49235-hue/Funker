package app.funkerlitelab

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.Locale

/** Called from Python (bridge.py). Return false to cancel. */
fun interface ProgressSink {
    fun update(stage: String, done: Int, total: Int, name: String): Boolean
}

data class ModItem(
    val name: String, val path: String, val kind: String, val supported: Boolean,
    val note: String, val status: String, val backup: Boolean
)

class MainActivity : Activity() {
    private lateinit var ap: Appearance
    private lateinit var pal: Palette
    private lateinit var kit: Ui

    private val reqMod = 1
    private val reqOut = 2
    private val reqAllFiles = 3
    private val reqRoot = 4

    private var screen = "home"          // home | appearance | roots
    private var draft: Appearance? = null

    private var modTree: Uri? = null
    private var outTree: Uri? = null
    @Volatile private var cancelled = false
    @Volatile private var running = false
    @Volatile private var scanning = false

    // state that must survive a UI rebuild (theme change, rotation, system day/night switch)
    private var typedText = ""
    private var levelIndex = 1
    private var progStage = ""
    private var progDone = 0
    private var progTotal = 0
    private var progName = ""
    private var resultTitleText = ""
    private var resultBodyText = ""
    private var resultKind = ""          // ok | warn | bad | "" (hidden)
    private var scanJson: String? = null
    private var scanError = ""

    // views of the current home screen
    private lateinit var typedPath: EditText
    private lateinit var modStatus: TextView
    private lateinit var outStatus: TextView
    private lateinit var grantBtn: Button
    private lateinit var strengthGroup: RadioGroup
    private lateinit var startBtn: Button
    private lateinit var cancelBtn: Button
    private lateinit var progressCard: LinearLayout
    private lateinit var progressBar: ProgressBar
    private lateinit var stageText: TextView
    private lateinit var fileText: TextView
    private lateinit var resultCard: LinearLayout
    private lateinit var resultTitleV: TextView
    private lateinit var resultBodyV: TextView
    private lateinit var modsBox: LinearLayout
    private lateinit var scanBtn: Button
    private var previewHolder: LinearLayout? = null

    private val strengths = listOf("light", "balanced", "strong", "maximum")
    private val levelLabels = listOf(
        "Light\nLossless only. Image sizes never change.",
        "Balanced\nAlso shrinks very large character atlases to fit 2048 px.",
        "Strong\nCharacter atlases fit 1536 px and sprite sheets are re-packed.",
        "Maximum\nCharacter atlases fit 1024 px and sprite sheets are re-packed. Smallest, may look softer."
    )

    // ------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ap = Themes.load(this)
        levelIndex = prefs().getInt("level", 1).coerceIn(0, 3)
        restoreSavedFolders()
        render()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        render()   // follows the device day/night switch in Auto mode without restarting a running task
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (screen != "home") { screen = "home"; draft = null; render() } else super.onBackPressed()
    }

    override fun onResume() { super.onResume(); if (screen == "home" && ::modStatus.isInitialized) refreshModStatus() }

    private fun prefs() = getSharedPreferences("flab", Context.MODE_PRIVATE)

    private fun applyTheme() {
        pal = Themes.resolve(this, ap)
        kit = Ui(this, pal)
        window.statusBarColor = pal.bg
        window.navigationBarColor = pal.bg
        var flags = 0
        if (!pal.night) {
            flags = flags or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            if (Build.VERSION.SDK_INT >= 26) flags = flags or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }
        window.decorView.systemUiVisibility = flags
    }

    private fun render() {
        applyTheme()
        previewHolder = null
        val v = when (screen) {
            "appearance" -> buildAppearance()
            "roots" -> buildRoots()
            else -> buildHome()
        }
        setContentView(v)
        if (screen == "home") { refreshModStatus(); refreshOutStatus() }
    }

    private fun scroll(root: View): ScrollView = ScrollView(this).apply {
        setBackgroundColor(pal.bg); isFillViewport = true; addView(root)
    }

    private fun page(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(kit.dp(16), kit.dp(20), kit.dp(16), kit.dp(28))
    }

    // ------------------------------------------------------------ dialogs

    private fun dialog(title: String, message: String, actions: List<Triple<String, Boolean, () -> Unit>>) {
        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val box = kit.card(0)
        box.background = kit.shape(pal.surface, pal.rCard, pal.outline)
        box.addView(kit.heading(title))
        box.addView(kit.body(message, pal.text, 14f))
        for (a in actions) {
            val b = kit.button(a.first, a.second)
            b.setOnClickListener { d.dismiss(); a.third() }
            box.addView(b)
        }
        val holder = FrameLayout(this)
        holder.addView(box, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        d.setContentView(holder)
        d.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        d.window?.setLayout((resources.displayMetrics.widthPixels * 0.92).toInt(), WindowManager.LayoutParams.WRAP_CONTENT)
        d.show()
    }

    private fun info(title: String, message: String) =
        dialog(title, message, listOf(Triple("OK", true, {})))

    // ------------------------------------------------------------ HOME

    private fun buildHome(): View {
        val root = page()

        val head = kit.header()
        val titleRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val titleBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            addView(kit.title("Funker Lite Lab"))
        }
        val styleBtn = kit.button("Appearance", false, 0)
        styleBtn.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        styleBtn.setOnClickListener { screen = "appearance"; draft = ap; render() }
        titleRow.addView(titleBox); titleRow.addView(styleBtn)
        head.addView(titleRow)
        head.addView(kit.body("Make FNF mods lighter for weak phones. Your original is only replaced after the optimized copy passed validation, and it is kept in Downloads."))
        root.addView(head)

        // ---- 1. discovered mods
        val mods = kit.card()
        mods.addView(kit.heading("Your mods"))
        mods.addView(kit.body("Tap a mod to optimize it. The original moves to Downloads as a backup and the optimized copy (name + _opt) takes its place."))
        if (!hasAllFiles()) {
            mods.addView(kit.body("File access is needed to scan and replace mods in shared storage.", pal.warn))
            val g = kit.button("Grant file access", true)
            g.setOnClickListener { requestAllFiles() }
            mods.addView(g)
        }
        scanBtn = kit.button(if (scanning) "Scanning..." else "Scan for mods", hasAllFiles())
        kit.setEnabledLook(scanBtn, !scanning)
        scanBtn.setOnClickListener { scanMods() }
        mods.addView(scanBtn)
        val rootsBtn = kit.button("Mod folders (" + loadRoots().size + ")", false)
        rootsBtn.setOnClickListener { screen = "roots"; render() }
        mods.addView(rootsBtn)
        modsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        mods.addView(modsBox)
        renderMods(modsBox)
        root.addView(mods)

        // ---- 2. level + switches
        val st = kit.card()
        st.addView(kit.heading("Optimization level"))
        st.addView(kit.body("The app decides image by image what is safe. The level only sets how far it may go."))
        strengthGroup = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        levelLabels.forEachIndexed { i, l -> strengthGroup.addView(kit.radio(100 + i, l)) }
        strengthGroup.check(100 + levelIndex)
        strengthGroup.setOnCheckedChangeListener { _, id ->
            levelIndex = (id - 100).coerceIn(0, 3); prefs().edit().putInt("level", levelIndex).apply()
        }
        st.addView(strengthGroup)

        st.addView(kit.sectionLabel("Memory (RAM)"))
        st.addView(kit.switchRow("Merge identical frames", "Frames with the same pixels share one place in the sprite sheet (strong / maximum).",
            prefs().getBoolean("opt_dedupe", true)) { prefs().edit().putBoolean("opt_dedupe", it).apply() })
        st.addView(kit.switchRow("Re-pack sprite sheets", "Tighter sheets use less texture memory (strong / maximum). Off = resize only.",
            prefs().getBoolean("opt_repack", true)) { prefs().edit().putBoolean("opt_repack", it).apply() })
        st.addView(kit.sectionLabel("Smoothness (FPS)"))
        st.addView(kit.switchRow("Trim transparent borders", "Smaller drawn rectangles mean less GPU work per frame. Pictures stay in the same place.",
            prefs().getBoolean("opt_fps", true)) { prefs().edit().putBoolean("opt_fps", it).apply() })
        st.addView(kit.sectionLabel("Output"))
        st.addView(kit.switchRow("Always save as ZIP", "Off = folder mods stay folders (what Psych Engine reads), ZIP mods stay ZIP.",
            prefs().getString("opt_output", "auto") == "zip") { prefs().edit().putString("opt_output", if (it) "zip" else "auto").apply() })
        root.addView(st)

        // ---- progress
        progressCard = kit.card()
        stageText = kit.heading("Working...")
        progressBar = kit.progress()
        fileText = kit.body("")
        cancelBtn = kit.button("Cancel", false)
        cancelBtn.setOnClickListener { cancelled = true; cancelBtn.isEnabled = false; stageText.text = "Cancelling..." }
        progressCard.addView(stageText); progressCard.addView(progressBar)
        progressCard.addView(fileText); progressCard.addView(cancelBtn)
        progressCard.visibility = if (running) View.VISIBLE else View.GONE
        root.addView(progressCard)
        applyProgress()

        // ---- result
        resultCard = kit.card()
        resultTitleV = kit.heading("")
        resultBodyV = kit.body("", pal.text, 14f)
        resultCard.addView(resultTitleV); resultCard.addView(resultBodyV)
        showStoredResult()
        root.addView(resultCard)

        // ---- manual mode (unchanged workflow)
        val man = kit.card()
        man.addView(kit.heading("Other mod (manual)"))
        man.addView(kit.body("For a mod that is not in the list: pick or type its folder, choose where the new ZIP goes."))
        val pick = kit.button("Choose mod folder", true)
        pick.setOnClickListener { pickFolder(reqMod) }
        man.addView(pick)
        man.addView(kit.body("or type / paste a path:"))
        typedPath = kit.field("/storage/emulated/0/.PsychEngine/mods/MyMod")
        typedPath.setText(typedText)
        typedPath.contentDescription = "Mod folder path"
        typedPath.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                typedText = s?.toString() ?: ""
                if (!s.isNullOrBlank() && modTree != null) { modTree = null }
                refreshModStatus()
            }
        })
        man.addView(typedPath)
        modStatus = kit.body("")
        man.addView(modStatus)
        grantBtn = kit.button("Grant file access (needed for typed paths)", false)
        grantBtn.visibility = View.GONE
        grantBtn.setOnClickListener { requestAllFiles() }
        man.addView(grantBtn)
        val outBtn = kit.button("Choose output folder", true)
        outBtn.setOnClickListener { pickFolder(reqOut) }
        man.addView(outBtn)
        outStatus = kit.body("")
        man.addView(outStatus)
        startBtn = kit.button("Start optimizing", true)
        kit.setEnabledLook(startBtn, !running)
        startBtn.setOnClickListener { startOptimize() }
        man.addView(startBtn)
        root.addView(man)

        return scroll(root)
    }

    private fun optionsJson(): String {
        val o = JSONObject()
        o.put("fps", prefs().getBoolean("opt_fps", true))
        o.put("dedupe", prefs().getBoolean("opt_dedupe", true))
        if (!prefs().getBoolean("opt_repack", true)) o.put("repack", false)
        return o.toString()
    }

    private fun outputMode(): String = prefs().getString("opt_output", "auto") ?: "auto"

    // ------------------------------------------------------------ mod discovery

    private fun defaultRoots(): List<String> = listOf("/storage/emulated/0/.PsychEngine/mods")

    private fun loadRoots(): List<String> {
        val raw = prefs().getString("roots", null) ?: return defaultRoots()
        return try {
            val a = JSONArray(raw)
            val out = ArrayList<String>()
            for (i in 0 until a.length()) out.add(a.getString(i))
            if (out.isEmpty()) defaultRoots() else out
        } catch (e: Exception) { defaultRoots() }
    }

    private fun saveRoots(list: List<String>) {
        prefs().edit().putString("roots", JSONArray(list).toString()).apply()
    }

    @Suppress("DEPRECATION")
    private fun downloadsDir(): String = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).absolutePath

    private fun ensurePython() { if (!Python.isStarted()) Python.start(AndroidPlatform(this)) }

    private fun scanMods() {
        if (scanning || running) return
        scanning = true; scanError = ""
        scanBtn.text = "Scanning..."; kit.setEnabledLook(scanBtn, false)
        modsBox.removeAllViews(); modsBox.addView(kit.body("Scanning..."))
        val rootsJson = JSONArray(loadRoots()).toString()
        val dl = downloadsDir()
        Thread {
            try {
                ensurePython()
                val json = Python.getInstance().getModule("bridge").callAttr("discover", rootsJson, dl).toString()
                scanJson = json
            } catch (e: Exception) {
                scanJson = null
                scanError = "Scan failed: " + e.javaClass.simpleName + ": " + e.message
            }
            scanning = false
            runOnUiThread { if (screen == "home") render() }
        }.start()
    }

    private fun parseMods(root: JSONObject): List<ModItem> {
        val a = root.getJSONArray("mods")
        val out = ArrayList<ModItem>()
        for (i in 0 until a.length()) {
            val m = a.getJSONObject(i)
            out.add(ModItem(m.getString("name"), m.getString("path"), m.getString("kind"), m.getBoolean("supported"),
                m.optString("note"), m.getString("status"), m.optBoolean("backup_in_downloads")))
        }
        return out
    }

    private fun renderMods(box: LinearLayout) {
        box.removeAllViews()
        if (scanning) { box.addView(kit.body("Scanning...")); return }
        val json = scanJson
        if (json == null) {
            box.addView(kit.body(if (scanError.isEmpty()) "Tap \"Scan for mods\" to list the mods in your mod folders." else scanError,
                if (scanError.isEmpty()) pal.muted else pal.bad))
            return
        }
        val o = JSONObject(json)
        val roots = o.getJSONArray("roots")
        if (o.optString("error").isNotEmpty()) box.addView(kit.body(o.getString("error"), pal.bad))
        for (i in 0 until roots.length()) {
            val r = roots.getJSONObject(i)
            box.addView(kit.body(r.getString("path"), pal.goldText, 12f))
            if (r.getString("state") != "ok") {
                box.addView(kit.body(r.getString("message"), pal.warn))
                continue
            }
            val mods = parseMods(r)
            if (mods.isEmpty()) box.addView(kit.body("No mods found in this folder."))
            for (m in mods) box.addView(modRow(m))
        }
    }

    private fun modRow(m: ModItem): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.background = kit.shape(pal.surface2, pal.rField)
        row.setPadding(kit.px(12), kit.dp(10), kit.px(12), kit.dp(10))
        row.layoutParams = kit.lp(8)
        row.isClickable = true
        row.setOnClickListener { showModDialog(m) }
        val texts = LinearLayout(this)
        texts.orientation = LinearLayout.VERTICAL
        texts.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        texts.addView(TextView(this).apply { text = m.name; setTextColor(pal.text); textSize = 15f })
        val sub = (if (m.kind == "zip") "ZIP" else if (m.kind == "folder") "Folder" else "Archive") +
            (if (m.backup) "  -  backup in Downloads" else "") + (if (m.note.isNotEmpty()) "  -  " + m.note else "")
        texts.addView(TextView(this).apply { text = sub; setTextColor(pal.muted); textSize = 12f })
        row.addView(texts)
        val chip = when {
            !m.supported -> kit.chip("Unsupported", pal.bad)
            m.status == "optimized" -> kit.chip("Optimized", pal.ok)
            m.status == "has_optimized" -> kit.chip("Has _opt copy", pal.goldText)
            else -> kit.chip("Original", pal.muted)
        }
        row.addView(chip)
        return row
    }

    private fun showModDialog(m: ModItem) {
        if (running) { toast("Wait for the running task to finish."); return }
        val level = strengths[levelIndex]
        val actions = ArrayList<Triple<String, Boolean, () -> Unit>>()
        val msg: String
        if (!m.supported) {
            msg = "This item cannot be optimized: " + m.note
        } else if (m.status == "optimized") {
            msg = "This already is an optimized copy. Optimize the original mod instead."
        } else {
            msg = "Level: " + level + "\nType: " + (if (m.kind == "zip") "ZIP mod" else "folder mod") + "\n" + m.path +
                (if (m.status == "has_optimized") "\n\nAn optimized copy already exists; a new one gets a numbered name and nothing is overwritten." else "")
            actions.add(Triple("Optimize and replace...", true, { confirmReplace(m) }))
            if (m.kind == "folder") actions.add(Triple("Use in manual mode", false, {
                typedText = m.path; modTree = null; render()
            }))
        }
        actions.add(Triple("Close", false, {}))
        dialog(m.name, msg, actions)
    }

    private fun confirmReplace(m: ModItem) {
        if (!hasAllFiles()) {
            dialog("File access needed",
                "Replacing a mod moves files inside shared storage, which needs \"All files access\". Without it the app can only write a new ZIP into a folder you pick (manual mode).",
                listOf(Triple("Grant file access", true, { requestAllFiles() }), Triple("Cancel", false, {})))
            return
        }
        val stem = if (m.name.lowercase(Locale.US).endsWith(".zip")) m.name.dropLast(4) else m.name
        val newName = stem + "_opt" + (if (m.kind == "zip") ".zip" else "")
        dialog("Optimize and replace?",
            "1. An optimized copy (" + newName + ") is created next to the original and checked.\n" +
                "2. Only if it passes, the original moves to Downloads as a backup.\n" +
                "3. The optimized copy takes its place in the mods folder.\n\n" +
                "If anything fails, the original stays or is put back.\n" +
                "The game sees the new name as a different mod: enable it in the mods menu, and scripts that use the old folder name may need the old name.",
            listOf(Triple("Start", true, { startReplace(m) }), Triple("Cancel", false, {})))
    }

    private fun startReplace(m: ModItem) {
        if (running) return
        val strength = strengths[levelIndex]
        val dl = downloadsDir()
        val opts = optionsJson()
        val outMode = outputMode()
        running = true; cancelled = false
        resultKind = ""
        setBusy(true)
        Thread {
            try {
                ensurePython()
                val sink = ProgressSink { stage, done, total, name -> postProgress(stage, done, total, name); !cancelled }
                val json = Python.getInstance().getModule("bridge")
                    .callAttr("run_replace", m.path, strength, dl, cacheDir.absolutePath, opts, outMode, sink).toString()
                val r = JSONObject(json)
                runOnUiThread { showReplaceResult(r) }
            } catch (e: OutOfMemoryError) {
                runOnUiThread { showError("Ran out of memory on this device. Try a lighter level or close other apps. Your mod was not changed.") }
            } catch (e: Exception) {
                runOnUiThread { showError("Unexpected error: " + e.javaClass.simpleName + ": " + e.message + "\nCheck your mods folder and Downloads before retrying.") }
            } finally {
                running = false
                runOnUiThread { setBusy(false); scanJson = null; if (screen == "home") scanMods() }
            }
        }.start()
    }

    // ------------------------------------------------------------ roots screen

    private fun buildRoots(): View {
        val root = page()
        val back = kit.button("Back", false, 0)
        back.setOnClickListener { screen = "home"; render() }
        root.addView(back)
        root.addView(kit.title("Mod folders", 22f))
        root.addView(kit.body("Folders that are scanned for mods. Engines keep mods in different places, so add yours. Only the folder of this phone's Psych Engine is listed by default."))
        val roots = loadRoots()
        val c = kit.card()
        roots.forEach { r ->
            val line = LinearLayout(this)
            line.orientation = LinearLayout.HORIZONTAL; line.gravity = Gravity.CENTER_VERTICAL
            line.addView(TextView(this).apply {
                text = r; setTextColor(pal.text); textSize = 13f
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            })
            val rm = kit.button("Remove", false, 0)
            rm.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            rm.setOnClickListener { saveRoots(roots.filter { it != r }); scanJson = null; render() }
            line.addView(rm)
            c.addView(line)
        }
        root.addView(c)
        val add = kit.card()
        add.addView(kit.heading("Add a folder"))
        val f = kit.field("/storage/emulated/0/MyEngine/mods")
        add.addView(f)
        val addBtn = kit.button("Add typed path", true)
        addBtn.setOnClickListener {
            val t = f.text.toString().trim().trimEnd('/')
            if (t.isEmpty() || !t.startsWith("/")) toast("Type a full path starting with /")
            else if (roots.contains(t)) toast("Already in the list.")
            else { saveRoots(roots + t); scanJson = null; render() }
        }
        add.addView(addBtn)
        val pickBtn = kit.button("Pick a folder", false)
        pickBtn.setOnClickListener { pickFolder(reqRoot) }
        add.addView(pickBtn)
        val defBtn = kit.button("Restore default list", false)
        defBtn.setOnClickListener { prefs().edit().remove("roots").apply(); scanJson = null; render() }
        add.addView(defBtn)
        root.addView(add)
        return scroll(root)
    }

    private fun treeToPath(uri: Uri): String? {
        val id = Uri.decode(DocumentsContract.getTreeDocumentId(uri))
        val vol = id.substringBefore(':')
        val rel = id.substringAfter(':', "").trim('/')
        val base = if (vol == "primary") "/storage/emulated/0" else "/storage/" + vol
        return if (vol.isEmpty()) null else if (rel.isEmpty()) base else base + "/" + rel
    }

    // ------------------------------------------------------------ appearance screen

    private fun cap(s: String) = s.replaceFirstChar { it.uppercase() }

    private fun optionGroup(
        options: List<Pair<String, String>>, selected: String, horizontal: Boolean,
        dotColor: ((String) -> Int)?, onPick: (String) -> Unit
    ): LinearLayout {
        val group = LinearLayout(this)
        group.orientation = if (horizontal) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
        var current = selected
        val rows = ArrayList<Pair<String, LinearLayout>>()
        fun style() {
            for (r in rows) {
                val on = r.first == current
                r.second.background = if (on) kit.shape(pal.surface2, pal.rField, pal.fill) else kit.shape(pal.surface, pal.rField, pal.outline)
            }
        }
        for (o in options) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(kit.px(12), kit.dp(10), kit.px(12), kit.dp(10))
            val lp = if (horizontal) LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                     else LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = kit.dp(6)
            if (horizontal) lp.marginEnd = kit.px(6)
            row.layoutParams = lp
            if (dotColor != null) {
                val dot = View(this)
                dot.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(dotColor(o.first)); setStroke(kit.px(1), pal.outline) }
                dot.layoutParams = LinearLayout.LayoutParams(kit.px(22), kit.px(22)).apply { marginEnd = kit.px(10) }
                row.addView(dot)
            }
            row.addView(TextView(this).apply { text = o.second; setTextColor(pal.text); textSize = 14f })
            row.isClickable = true
            row.setOnClickListener { current = o.first; style(); onPick(o.first) }
            rows.add(Pair(o.first, row))
            group.addView(row)
        }
        style()
        return group
    }

    private fun swatch(section: String, key: String, field: String, night: Boolean): Int {
        val t = Themes.data(this)
        val mode = if (night) "night" else "day"
        return try {
            when (section) {
                "presets" -> Color.parseColor(t.getJSONObject("presets").getJSONObject(key).getJSONObject(mode).getString("surface"))
                "gold" -> Color.parseColor(t.getJSONObject("gold").getJSONObject(key).getJSONObject(mode).getString(field))
                else -> {
                    val b = t.getJSONObject("background").getJSONObject(key)
                    if (b.has(mode)) Color.parseColor(b.getJSONObject(mode).getString("bg")) else pal.surface2
                }
            }
        } catch (e: Exception) { pal.surface2 }
    }

    private fun buildPreview(a: Appearance): View {
        val dp = Themes.resolve(this, a)
        val u = Ui(this, dp)
        val wrap = LinearLayout(this)
        wrap.orientation = LinearLayout.VERTICAL
        wrap.background = u.shape(dp.bg, dp.rCard, dp.outline)
        wrap.setPadding(u.px(10), u.px(10), u.px(10), u.px(10))
        val c = u.card(0)
        c.addView(u.heading("Preview"))
        c.addView(u.body("Funker Lite Lab makes mods lighter.", dp.text, 13f))
        val btns = LinearLayout(this)
        btns.orientation = LinearLayout.HORIZONTAL
        val b1 = u.button("Optimize", true, 8)
        val b2 = u.button("Cancel", false, 8)
        b1.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { topMargin = u.dp(8); marginEnd = u.px(8) }
        b2.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { topMargin = u.dp(8) }
        btns.addView(b1); btns.addView(b2)
        c.addView(btns)
        val chips = LinearLayout(this)
        chips.orientation = LinearLayout.HORIZONTAL
        chips.setPadding(0, u.dp(10), 0, 0)
        for (ch in listOf(u.chip("Optimized", dp.ok), u.chip("Original", dp.muted), u.chip("Warning", dp.warn), u.chip("Failed", dp.bad))) {
            ch.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = u.px(6) }
            chips.addView(ch)
        }
        c.addView(chips)
        val pb = u.progress()
        pb.isIndeterminate = false; pb.max = 100; pb.progress = 60
        c.addView(pb)
        wrap.addView(c)
        return wrap
    }

    private fun refreshPreview() {
        val h = previewHolder ?: return
        val d = draft ?: return
        h.removeAllViews()
        h.addView(buildPreview(d))
    }

    private fun buildAppearance(): View {
        val d0 = draft ?: ap
        draft = d0
        val night = Themes.isNight(this, d0)
        val outer = LinearLayout(this)
        outer.orientation = LinearLayout.VERTICAL
        outer.setBackgroundColor(pal.bg)
        outer.setPadding(kit.dp(16), kit.dp(16), kit.dp(16), kit.dp(8))

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL; bar.gravity = Gravity.CENTER_VERTICAL
        bar.addView(kit.title("Appearance", 22f).apply { layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f) })
        val back = kit.button("Back", false, 0)
        back.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        back.setOnClickListener { screen = "home"; draft = null; render() }
        bar.addView(back)
        outer.addView(bar)

        val holder = LinearLayout(this)
        holder.orientation = LinearLayout.VERTICAL
        holder.layoutParams = kit.lp(8)
        previewHolder = holder
        outer.addView(holder)
        refreshPreview()

        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL

        fun upd(f: (Appearance) -> Appearance) { draft = f(draft ?: d0); refreshPreview() }

        val c1 = kit.card(8)
        c1.addView(kit.heading("Day and night"))
        c1.addView(kit.body("Automatic follows your device's theme."))
        c1.addView(optionGroup(listOf(Pair("auto", "Automatic"), Pair("day", "Day"), Pair("night", "Night")), d0.mode, true, null) { k -> upd { it.copy(mode = k) } })
        list.addView(c1)

        val c2 = kit.card(8)
        c2.addView(kit.heading("Theme"))
        c2.addView(optionGroup(Themes.options(this, "presets"), d0.preset, false, { k -> swatch("presets", k, "", night) }) { k -> upd { it.copy(preset = k) } })
        c2.addView(kit.sectionLabel("Gold shade"))
        c2.addView(optionGroup(Themes.options(this, "gold"), d0.gold, false, { k -> swatch("gold", k, "fill", night) }) { k -> upd { it.copy(gold = k) } })
        c2.addView(kit.sectionLabel("Background"))
        c2.addView(optionGroup(Themes.options(this, "background"), d0.background, false, { k -> swatch("background", k, "", night) }) { k -> upd { it.copy(background = k) } })
        list.addView(c2)

        val c3 = kit.card(8)
        c3.addView(kit.heading("Layout"))
        c3.addView(kit.sectionLabel("Spacing"))
        c3.addView(optionGroup(Themes.options(this, "density").map { Pair(it.first, cap(it.first)) }, d0.density, true, null) { k -> upd { it.copy(density = k) } })
        c3.addView(kit.sectionLabel("Corners"))
        c3.addView(optionGroup(Themes.options(this, "corners").map { Pair(it.first, cap(it.first)) }, d0.corners, true, null) { k -> upd { it.copy(corners = k) } })
        c3.addView(kit.sectionLabel("Cards"))
        c3.addView(optionGroup(Themes.options(this, "cards").map { Pair(it.first, cap(it.first)) }, d0.cards, true, null) { k -> upd { it.copy(cards = k) } })
        c3.addView(kit.sectionLabel("Buttons"))
        c3.addView(optionGroup(Themes.options(this, "buttons").map { Pair(it.first, cap(it.first)) }, d0.buttons, true, null) { k -> upd { it.copy(buttons = k) } })
        list.addView(c3)

        val c4 = kit.card(8)
        c4.addView(kit.heading("Effects"))
        c4.addView(kit.body("All effects are static or very short, so they cost almost no CPU or GPU."))
        c4.addView(kit.switchRow("Header gradient", "A soft gradient behind the title.", d0.gradient) { on -> upd { it.copy(gradient = on) } })
        c4.addView(kit.switchRow("Shadows", "Elevation on elevated cards and filled buttons. Off = outlines only.", d0.shadows) { on -> upd { it.copy(shadows = on) } })
        c4.addView(kit.switchRow("Animations", "A short fade when results and progress appear.", d0.animations) { on -> upd { it.copy(animations = on) } })
        list.addView(c4)

        val sv = ScrollView(this)
        sv.addView(list)
        sv.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        outer.addView(sv)

        val actions = LinearLayout(this)
        actions.orientation = LinearLayout.HORIZONTAL
        val reset = kit.button("Reset to default", false, 8)
        reset.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { topMargin = kit.dp(8); marginEnd = kit.px(8) }
        reset.setOnClickListener {
            Themes.reset(this); ap = Themes.load(this); draft = ap; render()
        }
        val apply = kit.button("Apply", true, 8)
        apply.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { topMargin = kit.dp(8) }
        apply.setOnClickListener {
            val d = draft ?: ap
            Themes.save(this, d); ap = d; draft = null; screen = "home"; render()
        }
        actions.addView(reset); actions.addView(apply)
        outer.addView(actions)
        return outer
    }

    // ------------------------------------------------------------ folder picking

    private fun pickFolder(req: Int) {
        if (running) return
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            if (req == reqOut) addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        }
        try { startActivityForResult(i, req) } catch (e: Exception) {
            toast("No folder picker available on this device.")
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqAllFiles) { render(); return }
        val uri = data?.data
        if (resultCode != RESULT_OK || uri == null) {
            toast("Selection cancelled - nothing changed.")
            return
        }
        if (requestCode == reqRoot) {
            val path = treeToPath(uri)
            if (path == null) { toast("Could not turn that folder into a path.") } else {
                val roots = loadRoots()
                if (!roots.contains(path)) saveRoots(roots + path)
                scanJson = null
                toast("Added " + path)
            }
            render()
            return
        }
        val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or
            (if (requestCode == reqOut) Intent.FLAG_GRANT_WRITE_URI_PERMISSION else 0)
        try { contentResolver.takePersistableUriPermission(uri, flags) } catch (_: Exception) { /* still usable this session */ }
        if (requestCode == reqMod) {
            modTree = uri
            typedText = ""
            typedPath.setText("")
            prefs().edit().putString("modTree", uri.toString()).apply()
            refreshModStatus()
        } else if (requestCode == reqOut) {
            outTree = uri
            prefs().edit().putString("outTree", uri.toString()).apply()
            refreshOutStatus()
        }
    }

    private fun restoreSavedFolders() {
        val granted = contentResolver.persistedUriPermissions
        fun saved(key: String): Uri? = prefs().getString(key, null)?.let { Uri.parse(it) }?.takeIf { u ->
            granted.any { it.uri == u }
        }
        modTree = saved("modTree")
        outTree = saved("outTree")
    }

    private fun treeLabel(uri: Uri): String = Uri.decode(DocumentsContract.getTreeDocumentId(uri))

    private fun treeReadable(uri: Uri): Boolean = try {
        val id = DocumentsContract.getTreeDocumentId(uri)
        val kids = DocumentsContract.buildChildDocumentsUriUsingTree(uri, id)
        contentResolver.query(kids, arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID), null, null, null)?.use { true } ?: false
    } catch (e: Exception) { false }

    private fun hasAllFiles(): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager() else true

    private fun requestAllFiles() {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                startActivityForResult(
                    Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")), reqAllFiles)
            } else {
                requestPermissions(arrayOf(android.Manifest.permission.READ_EXTERNAL_STORAGE,
                    android.Manifest.permission.WRITE_EXTERNAL_STORAGE), 9)
            }
        } catch (e: Exception) {
            startActivityForResult(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION), reqAllFiles)
        }
    }

    private fun refreshModStatus() {
        if (!::typedPath.isInitialized || !::modStatus.isInitialized) return
        val typed = typedPath.text.toString().trim()
        grantBtn.visibility = View.GONE
        when {
            typed.isNotEmpty() -> {
                val f = File(typed)
                if (f.isDirectory && f.canRead()) {
                    modStatus.text = "Using typed path (readable)."; modStatus.setTextColor(pal.ok)
                } else {
                    modStatus.text = if (!hasAllFiles())
                        "Can't read this path. Grant file access below, or use \"Choose mod folder\"."
                    else "That path doesn't exist or isn't a readable folder."
                    modStatus.setTextColor(pal.bad)
                    if (!hasAllFiles()) grantBtn.visibility = View.VISIBLE
                }
            }
            modTree != null -> {
                if (treeReadable(modTree!!)) {
                    modStatus.text = "Selected: " + treeLabel(modTree!!); modStatus.setTextColor(pal.ok)
                } else {
                    modStatus.text = "Access to the selected folder was lost. Choose it again."; modStatus.setTextColor(pal.bad)
                    modTree = null
                }
            }
            else -> { modStatus.text = "No mod selected yet."; modStatus.setTextColor(pal.muted) }
        }
    }

    private fun refreshOutStatus() {
        if (!::outStatus.isInitialized) return
        val t = outTree
        if (t == null) { outStatus.text = "No output folder selected yet."; outStatus.setTextColor(pal.muted); return }
        if (treeReadable(t)) {
            outStatus.text = "Selected: " + treeLabel(t) + "\nA new ZIP is saved here; nothing is overwritten."
            outStatus.setTextColor(pal.ok)
        } else {
            outStatus.text = "Access to the output folder was lost. Choose it again."
            outStatus.setTextColor(pal.bad)
            outTree = null
        }
    }

    private fun toast(s: String) = android.widget.Toast.makeText(this, s, android.widget.Toast.LENGTH_SHORT).show()

    // ------------------------------------------------------------ manual processing (unchanged workflow)

    private fun startOptimize() {
        if (running) return
        val typed = typedPath.text.toString().trim()
        val out = outTree
        if (typed.isEmpty() && modTree == null) { toast("Choose a mod folder first."); return }
        if (out == null) { toast("Choose an output folder first."); return }
        if (typed.isNotEmpty()) {
            val f = File(typed)
            if (!f.isDirectory || !f.canRead()) { refreshModStatus(); toast("The typed path is not readable."); return }
        } else if (!treeReadable(modTree!!)) { refreshModStatus(); return }

        // never write the result into the mod being read
        val outId = DocumentsContract.getTreeDocumentId(out)
        val inId = modTree?.let { DocumentsContract.getTreeDocumentId(it) }
        if (inId != null && (outId == inId || outId.startsWith("$inId/"))) {
            showError("The output folder is inside the mod folder. Choose a different output folder."); return
        }
        if (typed.isNotEmpty() && outId.startsWith("primary:")) {
            val outPath = File(Environment.getExternalStorageDirectory(), outId.removePrefix("primary:")).canonicalPath
            val inPath = File(typed).canonicalPath
            if (outPath == inPath || outPath.startsWith(inPath + File.separator)) {
                showError("The output folder is inside the mod folder. Choose a different output folder."); return
            }
        }

        val strength = strengths[levelIndex]
        val opts = optionsJson()
        val modName = if (typed.isNotEmpty()) File(typed).name else treeLabel(modTree!!).substringAfterLast('/').substringAfterLast(':')
        val srcTree = if (typed.isEmpty()) modTree else null

        running = true; cancelled = false
        resultKind = ""
        setBusy(true)
        Thread {
            val work = File(cacheDir, "work-" + System.currentTimeMillis())
            try {
                work.mkdirs()
                val inputDir: File
                if (srcTree != null) {
                    inputDir = File(work, "in").also { it.mkdirs() }
                    postProgress("Copying mod into app storage", 0, 0, "")
                    var n = 0
                    copyTree(srcTree, inputDir) { name -> n++; if (n % 20 == 0) postProgress("Copying mod into app storage", 0, 0, "$n files  $name") }
                } else inputDir = File(typed)

                ensurePython()
                val zip = File(work, "result.zip")
                val sink = ProgressSink { stage, done, total, name -> postProgress(stage, done, total, name); !cancelled }
                val json = Python.getInstance().getModule("bridge")
                    .callAttr("run", inputDir.absolutePath, zip.absolutePath, strength, sink, opts).toString()
                val r = JSONObject(json)
                if (!r.optBoolean("ok", false)) {
                    val msg = if (r.optBoolean("cancelled")) "Cancelled. Nothing was saved."
                    else r.optString("error").ifEmpty { "Validation failed: " + r.optJSONArray("problems") } + "\nNothing was saved; your mod is untouched."
                    runOnUiThread { showError(msg) }
                    return@Thread
                }
                postProgress("Saving ZIP to output folder", 0, 0, "")
                val outName = "$modName-optimized-$strength.zip"
                saveZip(out, zip, outName)
                runOnUiThread { showResult(r, outName, treeLabel(out)) }
            } catch (e: OutOfMemoryError) {
                runOnUiThread { showError("Ran out of memory on this device. Try a lighter mod or close other apps.") }
            } catch (e: IOException) {
                runOnUiThread { showError("File error: " + e.message + "\n(Is there enough free space?)") }
            } catch (e: Exception) {
                runOnUiThread { showError("Unexpected error: " + e.javaClass.simpleName + ": " + e.message) }
            } finally {
                work.deleteRecursively()
                running = false
                runOnUiThread { setBusy(false) }
            }
        }.start()
    }

    private fun postProgress(stage: String, done: Int, total: Int, name: String) {
        progStage = stage; progDone = done; progTotal = total; progName = name
        runOnUiThread { applyProgress() }
    }

    private fun applyProgress() {
        if (screen != "home" || !::stageText.isInitialized) return
        stageText.text = if (progStage.isEmpty()) "Working..." else progStage
        if (progTotal > 0) {
            progressBar.isIndeterminate = false; progressBar.max = progTotal; progressBar.progress = progDone
            fileText.text = "$progDone of $progTotal\n$progName"
        } else { progressBar.isIndeterminate = true; fileText.text = progName }
    }

    private fun setBusy(b: Boolean) {
        progStage = if (b) "Starting..." else progStage
        if (b) { progDone = 0; progTotal = 0; progName = "" }
        if (screen != "home" || !::startBtn.isInitialized) return
        kit.setEnabledLook(startBtn, !b)
        progressCard.visibility = if (b) View.VISIBLE else View.GONE
        if (b) { resultCard.visibility = View.GONE; cancelBtn.isEnabled = true; kit.appear(progressCard) }
        applyProgress()
    }

    private fun safeName(n: String) = n.isNotEmpty() && n != "." && n != ".." && !n.contains('/') && !n.contains('\u0000')

    private fun copyTree(tree: Uri, dest: File, onFile: (String) -> Unit) {
        val rootId = DocumentsContract.getTreeDocumentId(tree)
        fun walk(docId: String, dir: File) {
            if (cancelled) throw IOException("Cancelled")
            val kidsUri = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
            val items = ArrayList<Triple<String, String, String>>()
            contentResolver.query(kidsUri, arrayOf(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE), null, null, null)?.use { c ->
                while (c.moveToNext()) items.add(Triple(c.getString(0), c.getString(1) ?: "", c.getString(2) ?: ""))
            } ?: throw IOException("Cannot list folder")
            for ((id, name, mime) in items) {
                if (!safeName(name)) throw IOException("Unsafe file name skipped: $name")
                val target = File(dir, name)
                if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                    target.mkdirs(); walk(id, target)
                } else {
                    val u = DocumentsContract.buildDocumentUriUsingTree(tree, id)
                    contentResolver.openInputStream(u)?.use { ins -> target.outputStream().use { ins.copyTo(it, 64 * 1024) } }
                        ?: throw IOException("Cannot read $name")
                    onFile(name)
                }
            }
        }
        walk(rootId, dest)
    }

    private fun saveZip(tree: Uri, zip: File, name: String) {
        val parent = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
        val doc = DocumentsContract.createDocument(contentResolver, parent, "application/zip", name)
            ?: throw IOException("Could not create the output file in the chosen folder")
        try {
            contentResolver.openOutputStream(doc, "w")?.use { o -> zip.inputStream().use { it.copyTo(o, 64 * 1024) } }
                ?: throw IOException("Could not write to the output folder")
        } catch (e: Exception) {
            try { DocumentsContract.deleteDocument(contentResolver, doc) } catch (_: Exception) {}
            throw if (e is IOException) e else IOException(e.message)
        }
    }

    // ------------------------------------------------------------ results

    private fun fmt(b: Long): String = when {
        b >= 1L shl 30 -> String.format(Locale.US, "%.2f GB", b / 1073741824.0)
        b >= 1L shl 20 -> String.format(Locale.US, "%.1f MB", b / 1048576.0)
        b >= 1L shl 10 -> String.format(Locale.US, "%.0f KB", b / 1024.0)
        else -> "$b B"
    }

    private fun showStoredResult() {
        if (resultKind.isEmpty()) { resultCard.visibility = View.GONE; return }
        resultCard.visibility = View.VISIBLE
        resultTitleV.text = resultTitleText
        resultTitleV.setTextColor(when (resultKind) { "ok" -> pal.ok; "warn" -> pal.warn; else -> pal.bad })
        resultBodyV.text = resultBodyText
    }

    private fun storeResult(title: String, body: String, kind: String) {
        resultTitleText = title; resultBodyText = body; resultKind = kind
        if (screen == "home" && ::resultCard.isInitialized) { showStoredResult(); kit.appear(resultCard) }
    }

    private fun showError(msg: String) = storeResult("Something went wrong", msg, "bad")

    /** Archive size and decoded texture memory are different numbers; both are labelled. */
    private fun reportLines(r: JSONObject): String {
        val sb = StringBuilder()
        val before = r.getLong("bytes_before"); val after = r.getLong("bytes_after")
        val diff = before - after
        sb.append("Files in mod: ${r.getInt("files_total")}  -  images: ${r.getInt("images_total")}\n")
        sb.append("Optimized: ${r.getInt("optimized")}  (resized: ${r.getInt("resized")}, re-packed: ${r.getInt("repacked")})\n")
        sb.append("Skipped: ${r.getInt("skipped")}  -  failed (original kept): ${r.getInt("failed")}\n\n")
        sb.append("ARCHIVE SIZE (files on disk)\n${fmt(before)} -> ${fmt(after)}  ")
        sb.append(if (diff >= 0) "(smaller by ${fmt(diff)})" else "(larger by ${fmt(-diff)})").append("\n")
        val tb = r.optLong("texture_bytes_before"); val ta = r.optLong("texture_bytes_after")
        if (tb > 0) {
            val pct = 100.0 * (tb - ta) / tb
            sb.append("\nTEXTURE MEMORY (decoded estimate)\n${fmt(tb)} -> ${fmt(ta)}  (" + String.format(Locale.US, "%.0f", pct) + "% less)\n")
            sb.append("This is a calculation from image sizes, not a measurement of the game's RAM.\n")
        }
        val fps = r.optJSONObject("fps")
        if (fps != null && fps.optBoolean("enabled")) {
            sb.append("\nSMOOTHNESS (FPS)\n")
            val n = fps.optInt("trimmed_atlases")
            if (n > 0) sb.append("Sprite rectangles drawn: " + String.format(Locale.US, "%.0f", fps.optDouble("drawn_area_cut_percent")) + "% smaller in $n sheet(s).\n")
            else sb.append("No sprite sheet could be trimmed.\n")
            val risks = fps.optJSONArray("frame_time_risks")
            if (risks != null && risks.length() > 0) {
                sb.append("Files that may cause hitches:\n")
                for (i in 0 until minOf(3, risks.length())) {
                    val o = risks.getJSONObject(i)
                    sb.append("- ${o.getString("file")} (${o.getInt("w")}x${o.getInt("h")})\n")
                }
            }
            sb.append("Frame rate was not measured. Test the mod on the phone.\n")
        }
        val d = r.getJSONArray("details")
        val reasons = LinkedHashMap<String, Int>()
        for (i in 0 until d.length()) {
            val o = d.getJSONObject(i)
            if (o.getString("action") == "skipped" || o.getString("action") == "failed" || o.getString("note").startsWith("not resized"))
                reasons.merge(o.getString("note").substringAfterLast("; "), 1, Int::plus)
        }
        if (reasons.isNotEmpty()) {
            sb.append("\nWhy some images were left as they are:\n")
            reasons.entries.sortedByDescending { it.value }.take(6).forEach { sb.append("- ${it.value} x ${it.key}\n") }
        }
        if (r.getInt("resized") > 0) sb.append("\nResized atlases were not tested in-game. Test the mod before deleting any backup.")
        return sb.toString()
    }

    private fun showResult(r: JSONObject, outName: String, where: String) {
        val sb = StringBuilder()
        sb.append("Saved as $outName\nin $where\n\n")
        sb.append(reportLines(r))
        sb.append("\nValidation: passed (ZIP readable, every file present)\n")
        storeResult("Done", sb.toString(), "ok")
    }

    private fun showReplaceResult(r: JSONObject) {
        val optOk = r.optBoolean("optimization_ok"); val valOk = r.optBoolean("validation_ok"); val repOk = r.optBoolean("replacement_ok")
        fun mark(b: Boolean) = if (b) "done" else "not done"
        val sb = StringBuilder()
        sb.append("Optimization: ${mark(optOk)}\nValidation: ${mark(valOk)}\nReplacement: ${mark(repOk)}\n")
        if (repOk) {
            sb.append("\nOptimized mod:\n${r.optString("final_path")}\n")
            sb.append("\nOriginal (backup):\n${r.optString("backup_path")}\n")
            if (r.optBoolean("renamed_for_collision")) sb.append("\nA copy with that name already existed, so a numbered name was used. Nothing was overwritten.\n")
            sb.append("\nEnable the new mod in the game's mods menu. Test it before deleting the backup.\n")
        } else {
            sb.append("\n" + r.optString("error") + "\n")
            val rb = r.opt("rolled_back")
            if (rb == true) sb.append("\nThe original was put back. Nothing changed.\n")
            else if (rb == false) sb.append("\nRollback was incomplete. Check the locations in the message above before doing anything else.\n")
            else sb.append("\nYour original mod was not touched.\n")
        }
        val rep = r.optJSONObject("report")
        if (rep != null && rep.has("bytes_before")) sb.append("\n").append(reportLines(rep))
        val kind = if (repOk) "ok" else if (optOk && valOk) "warn" else if (r.opt("rolled_back") == false) "bad" else "bad"
        val title = if (repOk) "Optimized and replaced" else if (optOk && valOk) "Optimized, but NOT replaced" else "Not optimized - nothing was changed"
        storeResult(title, sb.toString(), kind)
    }
}
