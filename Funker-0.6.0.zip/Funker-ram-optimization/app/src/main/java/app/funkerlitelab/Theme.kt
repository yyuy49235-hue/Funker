package app.funkerlitelab

import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import org.json.JSONObject

/** The user's saved choices. Every field changes something on screen (see Ui.kt). */
data class Appearance(
    val preset: String, val mode: String, val gold: String, val background: String,
    val density: String, val cards: String, val buttons: String, val corners: String,
    val gradient: Boolean, val shadows: Boolean, val animations: Boolean
)

/** Resolved colours and metrics for one Appearance in day or night. */
class Palette(
    val night: Boolean,
    val bg: Int, val surface: Int, val surface2: Int, val text: Int, val muted: Int, val outline: Int,
    val fill: Int, val goldText: Int, val onFill: Int, val softFill: Int,
    val ok: Int, val warn: Int, val bad: Int,
    val space: Float, val rCard: Int, val rButton: Int, val rField: Int,
    val cards: String, val buttons: String,
    val gradient: Boolean, val shadows: Boolean, val animations: Boolean
)

/** Reads assets/themes.json (the same file tests/test_themes.py checks for contrast). */
object Themes {
    private var cache: JSONObject? = null
    private const val PREFS = "flab_appearance"

    fun data(ctx: Context): JSONObject {
        cache?.let { return it }
        val text = ctx.assets.open("themes.json").bufferedReader().use { it.readText() }
        val j = JSONObject(text)
        cache = j
        return j
    }

    /** (key, label) pairs of one section, in file order. */
    fun options(ctx: Context, section: String): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        val raw = data(ctx).get(section)
        if (raw is org.json.JSONArray) {  // "cards", "buttons", "modes" are plain lists
            for (i in 0 until raw.length()) out.add(Pair(raw.getString(i), raw.getString(i)))
            return out
        }
        val obj = raw as JSONObject
        for (k in obj.keys()) {
            val v = obj.get(k)
            val label = if (v is JSONObject) v.optString("label", k) else k
            out.add(Pair(k, label))
        }
        return out
    }

    private fun pick(ctx: Context, section: String, value: String?, fallback: String): String {
        val obj = data(ctx).getJSONObject(section)
        return if (value != null && obj.has(value)) value else fallback
    }

    fun defaults(ctx: Context): Appearance {
        val d = data(ctx).getJSONObject("defaults")
        return Appearance(
            d.getString("preset"), d.getString("mode"), d.getString("gold"), d.getString("background"),
            d.getString("density"), d.getString("cards"), d.getString("buttons"), d.getString("corners"),
            d.getBoolean("gradient"), d.getBoolean("shadows"), d.getBoolean("animations")
        )
    }

    fun load(ctx: Context): Appearance {
        val d = defaults(ctx)
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val modes = data(ctx).getJSONArray("modes")
        val cards = data(ctx).getJSONArray("cards")
        val buttons = data(ctx).getJSONArray("buttons")
        fun inArray(a: org.json.JSONArray, v: String?, fb: String): String {
            if (v == null) return fb
            for (i in 0 until a.length()) if (a.getString(i) == v) return v
            return fb
        }
        return Appearance(
            pick(ctx, "presets", p.getString("preset", null), d.preset),
            inArray(modes, p.getString("mode", null), d.mode),
            pick(ctx, "gold", p.getString("gold", null), d.gold),
            pick(ctx, "background", p.getString("background", null), d.background),
            pick(ctx, "density", p.getString("density", null), d.density),
            inArray(cards, p.getString("cards", null), d.cards),
            inArray(buttons, p.getString("buttons", null), d.buttons),
            pick(ctx, "corners", p.getString("corners", null), d.corners),
            p.getBoolean("gradient", d.gradient), p.getBoolean("shadows", d.shadows), p.getBoolean("animations", d.animations)
        )
    }

    fun save(ctx: Context, a: Appearance) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("preset", a.preset).putString("mode", a.mode).putString("gold", a.gold)
            .putString("background", a.background).putString("density", a.density)
            .putString("cards", a.cards).putString("buttons", a.buttons).putString("corners", a.corners)
            .putBoolean("gradient", a.gradient).putBoolean("shadows", a.shadows).putBoolean("animations", a.animations)
            .apply()
    }

    fun reset(ctx: Context) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
    }

    /** Auto follows the device theme; day/night force it. */
    fun isNight(ctx: Context, a: Appearance): Boolean = when (a.mode) {
        "day" -> false
        "night" -> true
        else -> (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }

    private fun blend(fg: Int, bg: Int, a: Double): Int {
        fun ch(f: Int, b: Int) = Math.round(f * a + b * (1.0 - a)).toInt()
        return Color.rgb(ch(Color.red(fg), Color.red(bg)), ch(Color.green(fg), Color.green(bg)), ch(Color.blue(fg), Color.blue(bg)))
    }

    fun resolve(ctx: Context, a: Appearance): Palette {
        val t = data(ctx)
        val night = isNight(ctx, a)
        val mode = if (night) "night" else "day"
        val base = t.getJSONObject("presets").getJSONObject(a.preset).getJSONObject(mode)
        val bgOverride = t.getJSONObject("background").getJSONObject(a.background)
        val ov = if (bgOverride.has(mode)) bgOverride.getJSONObject(mode) else null
        fun c(key: String): Int = Color.parseColor((if (ov != null && ov.has(key)) ov else base).getString(key))
        val g = t.getJSONObject("gold").getJSONObject(a.gold).getJSONObject(mode)
        val s = t.getJSONObject("status").getJSONObject(mode)
        val corners = t.getJSONObject("corners").getJSONObject(a.corners)
        val surface = c("surface")
        val fill = Color.parseColor(g.getString("fill"))
        return Palette(
            night, c("bg"), surface, c("surface2"), c("text"), c("muted"), c("outline"),
            fill, Color.parseColor(g.getString("text")), Color.parseColor(g.getString("onFill")),
            blend(fill, surface, t.getDouble("soft_alpha")),
            Color.parseColor(s.getString("ok")), Color.parseColor(s.getString("warn")), Color.parseColor(s.getString("bad")),
            t.getJSONObject("density").getDouble(a.density).toFloat(),
            corners.getInt("card"), corners.getInt("button"), corners.getInt("field"),
            a.cards, a.buttons, a.gradient, a.shadows, a.animations
        )
    }
}
