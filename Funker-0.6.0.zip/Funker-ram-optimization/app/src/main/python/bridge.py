import json

from funkerlitelab import engine, library, replace


def _options(options_json):
    """Only the documented switches are accepted; anything else is ignored."""
    o = json.loads(options_json) if options_json else {}
    out = {}
    if "repack" in o:
        out["repack"] = None if o["repack"] is None else bool(o["repack"])
    if "dedupe" in o:
        out["dedupe"] = bool(o["dedupe"])
    if "fps" in o:
        out["fps"] = bool(o["fps"])
    if "max_dim" in o:
        out["max_dim"] = None if o["max_dim"] is None else int(o["max_dim"])
    return out


def _callback(sink):
    def cb(stage, done, total, name):
        if not sink.update(stage, int(done), int(total), name):
            raise engine.Cancelled()
        return True
    return cb


def run(input_dir, out_zip, strength, sink, options_json=None):
    try:
        return json.dumps(engine.optimize_mod(input_dir, out_zip, strength, _callback(sink), **_options(options_json)))
    except engine.Cancelled:
        return json.dumps({"ok": False, "cancelled": True, "error": "Cancelled"})
    except Exception as e:
        return json.dumps({"ok": False, "error": "%s: %s" % (type(e).__name__, e)})


def discover(roots_json, downloads):
    try:
        roots = json.loads(roots_json) if roots_json else None
        return json.dumps(library.discover(roots, downloads))
    except Exception as e:
        return json.dumps({"roots": [], "total": 0, "readable_roots": 0, "error": "%s: %s" % (type(e).__name__, e)})


def run_replace(mod_path, strength, downloads, work_dir, options_json, output, sink):
    try:
        r = replace.optimize_and_replace(mod_path, strength, downloads, work_dir=work_dir,
                                         options=_options(options_json), progress=_callback(sink), output=output or "auto")
        return json.dumps(r)
    except Exception as e:
        return json.dumps({"ok": False, "optimization_ok": False, "validation_ok": False, "replacement_ok": False,
                           "stage_failed": "unexpected", "error": "%s: %s" % (type(e).__name__, e)})
