"""Optimize one mod and swap it in safely.

Order of events (the original is never touched before step 4):
  1 optimize into a temp ZIP          2 validate it independently of the optimizer
  3 stage it next to the original under a hidden temp name (verified)
  4 move the original to the backup folder (copy + verify + delete when rename is not possible)
  5 rename the staged copy to its final name; if that fails, put the original back
The result keeps three separate verdicts: optimization_ok, validation_ok, replacement_ok.
"""
import hashlib
import os
import shutil
import tempfile
import zipfile
import xml.etree.ElementTree as ET
import json

from PIL import Image

from . import engine, library


class ReplaceError(Exception):
    def __init__(self, stage, msg):
        Exception.__init__(self, msg)
        self.stage, self.msg = stage, msg


# ------------------------------------------------------------------ helpers

def _sha(fobj):
    h = hashlib.sha256()
    for c in iter(lambda: fobj.read(1 << 20), b""):
        h.update(c)
    return h.hexdigest()


def tree_digest(path):
    """{relative path: (size, sha256)} for a folder, or {'': (size, sha)} for a single file."""
    if os.path.isfile(path):
        with open(path, "rb") as f:
            return {"": (os.path.getsize(path), _sha(f))}
    out = {}
    for dp, dn, fn in os.walk(path):
        rel_dir = os.path.relpath(dp, path).replace(os.sep, "/")
        if not fn and not dn and rel_dir != ".":
            out[rel_dir + "/"] = (0, "")
        for f in fn:
            p = os.path.join(dp, f)
            with open(p, "rb") as fh:
                out[os.path.relpath(p, path).replace(os.sep, "/")] = (os.path.getsize(p), _sha(fh))
    return out


def safe_extract(zip_path, dest):
    os.makedirs(dest, exist_ok=True)
    root = os.path.realpath(dest)
    with zipfile.ZipFile(zip_path) as zf:
        for info in zf.infolist():
            name = info.filename
            if name.startswith("/") or "\\" in name or ".." in name.split("/"):
                raise ReplaceError("extract", "unsafe path inside ZIP: " + name)
            target = os.path.realpath(os.path.join(dest, name))
            if target != root and not target.startswith(root + os.sep):
                raise ReplaceError("extract", "unsafe path inside ZIP: " + name)
            if name.endswith("/"):
                os.makedirs(target, exist_ok=True)
                continue
            os.makedirs(os.path.dirname(target), exist_ok=True)
            with zf.open(info) as src, open(target, "wb") as dst:
                shutil.copyfileobj(src, dst, 1 << 20)


def _free_bytes(path):
    return shutil.disk_usage(path).free


def _rm(path):
    try:
        if os.path.isdir(path) and not os.path.islink(path):
            shutil.rmtree(path)
        elif os.path.lexists(path):
            os.remove(path)
    except OSError:
        pass


def safe_move(src, dst):
    """Move a file or folder. Never overwrites. Rename first; otherwise copy, verify, then delete.

    Raises OSError on failure; src is intact unless the final delete step itself fails
    (then the complete verified copy is at dst and the error says so).
    """
    if os.path.lexists(dst):
        raise FileExistsError("destination already exists: " + dst)
    try:
        os.rename(src, dst)
        return "renamed"
    except OSError:
        pass  # cross-device link (EXDEV) or a storage layer that refuses rename: copy instead
    tmp = dst + ".flab-copying"
    _rm(tmp)
    try:
        if os.path.isdir(src):
            shutil.copytree(src, tmp, symlinks=False)
        else:
            shutil.copy2(src, tmp)
        if tree_digest(src) != tree_digest(tmp):
            raise OSError("copy did not verify (content differs)")
        os.rename(tmp, dst)
    except BaseException:
        _rm(tmp)
        raise
    try:
        if os.path.isdir(src):
            shutil.rmtree(src)
        else:
            os.remove(src)
    except OSError as e:
        restored = False
        try:  # put back whatever the failed delete removed, so the original is whole again
            if os.path.isdir(dst):
                shutil.copytree(dst, src, dirs_exist_ok=True)
            else:
                shutil.copy2(dst, src)
            restored = tree_digest(src) == tree_digest(dst)
        except OSError:
            pass
        if restored:
            _rm(dst)
            raise OSError("could not remove the original after copying; original restored (%s)" % e)
        raise OSError("could not remove the original after copying; a complete verified copy is at %s" % dst)
    return "copied"


def unique_name(directory, base, suffix, ext=""):
    """base+suffix+ext, or base+suffix+N+ext (N>=2) if that name is taken (case-insensitive)."""
    taken = {n.lower() for n in os.listdir(directory)} if os.path.isdir(directory) else set()
    n = 1
    while True:
        name = base + suffix + ("" if n == 1 else str(n)) + ext
        if name.lower() not in taken:
            return name
        n += 1


# --------------------------------------------------------------- validation

def _read_all(opener, rel):
    with opener(rel) as fo:
        return fo.read()


def validate_output(source_dir, out_path):
    """Check an optimized mod (ZIP file or folder) against the source folder. Returns a problem list.

    Independent of engine.optimize_mod's own check: every source file is present, nothing extra,
    untouched files are byte-identical, PNGs decode, XML/JSON parse, and every rewritten atlas
    still has its frames inside its image.
    """
    problems = []
    files, _, _ = engine.scan(source_dir)
    src = {rel: p for rel, p, _ in files}
    zf = zipfile.ZipFile(out_path) if os.path.isfile(out_path) else None
    try:
        if zf:
            bad = zf.testzip()
            if bad:
                problems.append("corrupt ZIP entry: " + bad)
            names = {i.filename for i in zf.infolist() if not i.filename.endswith("/")}
            opener = lambda rel: zf.open(rel)
        else:
            names = set()
            for dp, _, fn in os.walk(out_path):
                for f in fn:
                    names.add(os.path.relpath(os.path.join(dp, f), out_path).replace(os.sep, "/"))
            opener = lambda rel: open(os.path.join(out_path, rel), "rb")
        for rel in sorted(set(src) - names)[:20]:
            problems.append("missing in output: " + rel)
        for rel in sorted(names - set(src))[:20]:
            problems.append("extra file in output: " + rel)
        sizes, rewritten_xml = {}, []
        for rel in sorted(set(src) & names):
            low = rel.lower()
            try:
                if low.endswith(".png"):
                    with opener(rel) as fo:
                        im = Image.open(fo)
                        im.verify()
                        sizes[low] = im.size
                    continue
                data = _read_all(opener, rel)
                with open(src[rel], "rb") as sf:
                    same = sf.read() == data
                if low.endswith(".xml"):
                    ET.fromstring(data)
                    if not same:
                        rewritten_xml.append((rel, data))
                elif low.endswith(".json"):
                    json.loads(data.decode("utf-8-sig"))
                elif not same:
                    problems.append("changed unexpectedly: " + rel)
            except Exception as e:
                problems.append("%s: %s (%s)" % (rel, type(e).__name__, e))
        for rel, data in rewritten_xml:
            problems.extend(_atlas_problems(rel, data, sizes))
    finally:
        if zf:
            zf.close()
    return problems[:40]


def _atlas_problems(rel, data, sizes):
    root = ET.fromstring(data)
    ip = root.attrib.get("imagePath")
    if not ip:
        return []
    img = os.path.normpath(os.path.join(os.path.dirname(rel), ip)).replace(os.sep, "/").lower()
    if img not in sizes:
        return []
    W, H = sizes[img]
    out = []
    for e in root.iter():
        if e.tag.split("}")[-1] != "SubTexture":
            continue
        try:
            x, y, w, h = (float(e.attrib[k]) for k in ("x", "y", "width", "height"))
        except (KeyError, ValueError):
            continue
        if x < 0 or y < 0 or x + w > W + 0.5 or y + h > H + 0.5:
            out.append("%s: frame %s lies outside %s (%dx%d)" % (rel, e.attrib.get("name", "?"), img, W, H))
            if len(out) >= 3:
                break
    return out


# ------------------------------------------------------------------ workflow

def optimize_and_replace(mod_path, strength, downloads_dir, work_dir=None, options=None,
                         progress=None, output="auto"):
    """Returns a dict. Never raises for expected failures; the original is untouched unless
    replacement_ok is True (or rolled_back says it was restored)."""
    progress = progress or (lambda *a: True)
    options = dict(options or {})
    res = {"ok": False, "optimization_ok": False, "validation_ok": False, "replacement_ok": False,
           "stage_failed": None, "error": "", "original_path": mod_path, "final_path": None,
           "backup_path": None, "rolled_back": None, "renamed_for_collision": False, "report": None}
    work = None
    staged = None
    backup = None
    moved = False
    try:
        mod_path = os.path.abspath(mod_path)
        if not os.path.lexists(mod_path):
            raise ReplaceError("input", "the mod no longer exists: " + mod_path)
        supported, kind, note = library.classify(mod_path)
        if not supported:
            raise ReplaceError("input", "unsupported mod: " + (note or kind))
        mods_dir, name = os.path.split(mod_path)
        stem = library._stem(name)
        if library.is_opt_name(name):
            raise ReplaceError("input", "this looks like an already optimized copy (%s). Optimize the original instead." % name)
        if not os.path.isdir(downloads_dir):
            raise ReplaceError("backup-folder", "the backup folder does not exist or is not accessible: " + str(downloads_dir))
        if not os.access(downloads_dir, os.W_OK) or not os.access(mods_dir, os.W_OK):
            raise ReplaceError("permission", "no write permission for the mods folder or the backup folder (grant file access)")
        out_kind = kind if output == "auto" else output
        if kind == "zip" and out_kind == "folder":
            out_kind = "zip"  # a ZIP mod stays a ZIP
        work = tempfile.mkdtemp(prefix="flab_", dir=work_dir)

        # 1. input folder for the engine
        if kind == "zip":
            progress("Reading ZIP mod", 0, 0, name)
            try:
                safe_extract(mod_path, os.path.join(work, "in"))
            except zipfile.BadZipFile:
                raise ReplaceError("input", "the ZIP file is damaged")
            src_dir = os.path.join(work, "in")
        else:
            src_dir = mod_path
        need = sum(s for _, _, s in engine.scan(src_dir)[0])
        if _free_bytes(work) < need * 1.2 or _free_bytes(mods_dir) < need * 1.2:
            raise ReplaceError("space", "not enough free storage to optimize safely (need about %.0f MB)" % (need * 1.2 / 1048576.0))

        # 2. optimize
        opt_zip = os.path.join(work, "result.zip")
        rep = engine.optimize_mod(src_dir, opt_zip, strength, progress, **options)
        res["report"] = rep
        if not rep.get("ok"):
            raise ReplaceError("optimize", "the optimizer's own validation failed: " + "; ".join(rep.get("problems", [])))
        res["optimization_ok"] = True

        # 3. independent validation
        progress("Validating optimized mod", 0, 0, "")
        problems = validate_output(src_dir, opt_zip)
        if problems:
            res["problems"] = problems
            raise ReplaceError("validate", "validation failed: " + problems[0])
        res["validation_ok"] = True

        # 4. choose names (never overwrite anything that exists)
        final_name = unique_name(mods_dir, stem, library.OPT_SUFFIX, ".zip" if out_kind == "zip" else "")
        res["renamed_for_collision"] = final_name.lower() != (stem + library.OPT_SUFFIX + (".zip" if out_kind == "zip" else "")).lower()
        if os.path.lexists(os.path.join(downloads_dir, name)):
            backup_name = unique_name(downloads_dir, stem, "_original", ".zip" if kind == "zip" else "")
        else:
            backup_name = name
        final_path = os.path.join(mods_dir, final_name)
        backup_path = os.path.join(downloads_dir, backup_name)

        # 5. stage next to the original (hidden name), verified
        progress("Placing optimized mod", 0, 0, final_name)
        staged = os.path.join(mods_dir, "." + final_name + ".flab-part")
        _rm(staged)
        if out_kind == "zip":
            shutil.copyfile(opt_zip, staged)
            if tree_digest(opt_zip) != tree_digest(staged):
                raise ReplaceError("place", "the staged copy did not verify")
        else:
            safe_extract(opt_zip, staged)
            problems = validate_output(src_dir, staged)
            if problems:
                raise ReplaceError("place", "the staged folder did not verify: " + problems[0])

        # 6. move original to backup (point of no return starts here; rollback below)
        progress("Backing up original", 0, 0, name)
        try:
            safe_move(mod_path, backup_path)
        except OSError as e:
            raise ReplaceError("backup", "could not move the original to the backup folder: %s" % e)
        moved = True
        res["backup_path"] = backup_path

        # 7. publish
        try:
            os.rename(staged, final_path)
        except OSError as e:
            raise ReplaceError("place", "could not place the optimized mod: %s" % e)
        staged = None
        res.update(replacement_ok=True, ok=True, final_path=final_path)
        return res
    except ReplaceError as e:
        res["stage_failed"], res["error"] = e.stage, e.msg
    except engine.Cancelled:
        res["stage_failed"], res["error"] = "cancelled", "Cancelled. Nothing was changed."
    except Exception as e:  # unexpected: never hide it
        res["stage_failed"], res["error"] = "unexpected", "%s: %s" % (type(e).__name__, e)
    finally:
        if staged:
            _rm(staged)
        if work:
            shutil.rmtree(work, ignore_errors=True)
    # failure path: roll back if the original had already been moved
    if moved and res["backup_path"] and not os.path.lexists(res["original_path"]):
        try:
            safe_move(res["backup_path"], res["original_path"])
            res["rolled_back"] = True
            res["backup_path"] = None
        except OSError as e:
            res["rolled_back"] = False
            res["error"] += " | ROLLBACK FAILED (%s). Your original is safe at: %s" % (e, res["backup_path"])
    elif moved:
        res["rolled_back"] = False
    return res
