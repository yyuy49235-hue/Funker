"""FPS optimizer - a separate, switchable part of the pipeline.

What an external mod optimizer can and cannot do for frame time:
- CAN: make the GPU draw less. Every sprite frame is drawn as a rectangle; transparent margins
  inside that rectangle are still shaded. Trimming them (frameX/frameY keep the picture in the
  same place) shrinks the drawn rectangle. This is the one active FPS action ("trim").
- CAN: point at files that are likely to cause hitches (very large textures).
- CANNOT: change garbage collection, scheduling, shaders or anything inside the game engine.
Nothing here is a measurement of frame rate. Switch it off with optimize_mod(..., fps=False).
"""

GPU_SIDE_LIMIT = 4096        # many mid/low-end phone GPUs cap texture side near this
BIG_TEXTURE_BYTES = 64 << 20  # decoded RGBA >= 64 MB: slow to decode/upload on first use


def build_report(enabled, dims, tex_bytes, quad_before, quad_after, trimmed_atlases):
    """dims: {rel: (w, h)} after optimization; tex_bytes: {rel: decoded bytes after}."""
    if not enabled:
        return {"enabled": False}
    risks = []
    for rel in sorted(dims, key=lambda r: -tex_bytes.get(r, 0)):
        w, h = dims[rel]
        why = []
        if max(w, h) > GPU_SIDE_LIMIT:
            why.append("side %d px is above %d (may be refused or downscaled by some GPUs)" % (max(w, h), GPU_SIDE_LIMIT))
        if tex_bytes.get(rel, 0) >= BIG_TEXTURE_BYTES:
            why.append("%.0f MB decoded (slow first load, can hitch)" % (tex_bytes[rel] / 1048576.0))
        if why:
            risks.append({"file": rel, "w": w, "h": h, "why": "; ".join(why)})
    cut = 100.0 * (quad_before - quad_after) / quad_before if quad_before else 0.0
    return {"enabled": True, "trimmed_atlases": trimmed_atlases,
            "drawn_area_before": quad_before, "drawn_area_after": quad_after,
            "drawn_area_cut_percent": round(cut, 1),
            "frame_time_risks": risks[:15],
            "note": "drawn area = sum of frame rectangles; a static proxy for GPU fill work, not an FPS measurement"}
