"""Mod discovery. Read-only: nothing here writes, moves or deletes anything.

Roots are configurable. The default list holds only the folder already used on this phone
(.PsychEngine/mods); other engines keep mods elsewhere, so the user can add roots in the app.
A root the app cannot read is reported with a reason instead of being skipped silently.
"""
import os
import zipfile

DEFAULT_ROOTS = ["/storage/emulated/0/.PsychEngine/mods"]
OPT_SUFFIX = "_opt"
# a folder counts as a mod if it contains at least one of these entries
MOD_MARKERS = {"pack.json", "images", "data", "characters", "songs", "stages", "weeks", "scripts",
               "sounds", "music", "custom_events", "custom_notetypes", "shaders", "videos", "fonts", "mods"}
UNSUPPORTED_ARCHIVES = (".rar", ".7z", ".tar", ".gz")


def is_opt_name(name):
    """True for 'Tabi_opt' and 'Tabi_opt2' (collision-numbered)."""
    base = name[:-4] if name.lower().endswith(".zip") else name
    head = base.rstrip("0123456789")
    return head.endswith(OPT_SUFFIX) and (head == base or base[len(head):].isdigit())


def _stem(name):
    return name[:-4] if name.lower().endswith(".zip") else name


def _opt_siblings(stem, names):
    out = []
    for n in names:
        s = _stem(n)
        if s.startswith(stem + OPT_SUFFIX) and is_opt_name(s):
            tail = s[len(stem) + len(OPT_SUFFIX):]
            if tail == "" or tail.isdigit():
                out.append(n)
    return out


def classify(path):
    """Return (supported, kind, note) for one entry."""
    name = os.path.basename(path)
    if os.path.isdir(path):
        try:
            entries = {e.lower() for e in os.listdir(path)}
        except PermissionError:
            return False, "folder", "no permission to read this folder"
        except OSError as e:
            return False, "folder", "cannot read folder (%s)" % e.strerror
        if entries & MOD_MARKERS:
            return True, "folder", ""
        return False, "folder", "does not look like a mod (no pack.json, images, songs, ...)"
    low = name.lower()
    if low.endswith(".zip"):
        if zipfile.is_zipfile(path):
            return True, "zip", ""
        return False, "zip", "not a readable ZIP file"
    if low.endswith(UNSUPPORTED_ARCHIVES):
        return False, "archive", "this archive type is not supported; extract it to a folder first"
    return False, "file", ""


def scan_root(root, downloads=None):
    """Return {"path", "state", "message", "mods": [...]}. state: ok | missing | not_a_folder | no_permission | error."""
    res = {"path": root, "state": "ok", "message": "", "mods": []}
    if not os.path.exists(root):
        res.update(state="missing", message="folder does not exist")
        return res
    if not os.path.isdir(root):
        res.update(state="not_a_folder", message="this path is not a folder")
        return res
    try:
        names = sorted(os.listdir(root), key=str.lower)
    except PermissionError:
        res.update(state="no_permission", message="no permission to read this folder (grant file access, or pick it with the folder picker)")
        return res
    except OSError as e:
        res.update(state="error", message="cannot read folder: %s" % e.strerror)
        return res
    dl_names = set()
    if downloads and os.path.isdir(downloads):
        try:
            dl_names = {n.lower() for n in os.listdir(downloads)}
        except OSError:
            pass
    for n in names:
        if n.startswith("."):
            continue
        p = os.path.join(root, n)
        supported, kind, note = classify(p)
        if kind == "file" and not note:
            continue  # ordinary files (modsList.txt, ...) are not mods
        stem = _stem(n)
        if is_opt_name(n):
            status = "optimized"
        elif _opt_siblings(stem, names):
            status = "has_optimized"
        else:
            status = "original"
        has_backup = bool(dl_names & {n.lower(), stem.lower(), stem.lower() + "_original", stem.lower() + "_original.zip"})
        res["mods"].append({"name": n, "path": p, "kind": kind, "supported": supported, "note": note,
                            "status": status, "backup_in_downloads": has_backup})
    return res


def discover(roots=None, downloads=None):
    roots = list(roots) if roots else list(DEFAULT_ROOTS)
    seen, out = set(), []
    for r in roots:
        key = os.path.normpath(r)
        if key in seen:
            continue
        seen.add(key)
        out.append(scan_root(r, downloads))
    return {"roots": out, "total": sum(len(r["mods"]) for r in out),
            "readable_roots": sum(1 for r in out if r["state"] == "ok")}
