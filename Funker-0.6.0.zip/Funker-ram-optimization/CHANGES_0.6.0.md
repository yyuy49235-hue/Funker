# 0.6.0 - what changed, what was measured, what was NOT verified

Starting point: the exact 0.5.3 you sent. Its engine.py, bridge.py, MainActivity.kt and build.gradle.kts are kept unchanged in
`previous_versions/0.5.3/`. Tag it in git before merging: `git tag v0.5.3 <commit>` (the stable version you deleted is NOT recoverable from this ZIP).

## FPS instability: status = NOT root-caused
Without the old stable build, the game, or a device here, the cause could not be verified. What is known:
- Your report: stable build ~85-90 FPS at the start, 45-50 mid-song; 0.5.3 stutters from the start with less RAM.
  A drop that appears mid-song in the stable build is not caused by this optimizer (it was not in the pipeline). Heat throttling and
  garbage collection are typical causes; both are hypotheses, not findings.
- 0.5.3 always did three extra things at strong/maximum: re-pack atlases, trim transparent borders, merge identical frames.
  They are now independent switches, so one phone test can separate them: `tools/bisect_variants.py` (see below).
- Measured on the real Agoti_Cutscene_A atlas (104 frames, 2048x2048), static numbers only:
  | variant | decoded texture | drawn rectangle area |
  |---|---|---|
  | lossless only / repack only / trim only / resize only | 16.0 MB (no gain) | 0% / - / 0% / 0% |
  | repack + trim + merge identical (= 0.5.3 strong) | 6.3 MB (-60%) | -55% |
  | maximum (0.5.3 behaviour) | 6.5 MB (-59%) | -55% |
  On this atlas the whole memory gain comes from merging identical frames (62 unique of 104); trimming alone found nothing to re-pack.
  Repacking never made the image bigger than the original (the engine keeps the original otherwise).
  These are NOT in-game RAM or FPS numbers.

## How to find the culprit on the phone (about 20 minutes)
1. Pick ONE mod. In Termux: `pkg install python-pillow`, then
   `python tools/bisect_variants.py /storage/emulated/0/.PsychEngine/mods/YourMod /storage/emulated/0/Download/variants`
2. Copy each result into the mods folder as its own mod (unzip folders if your engine needs folders). Play the SAME song on each,
   phone restarted before each run, same graphics settings. Write down FPS in the first minute and near the end.
3. Send me the six pairs of numbers. The first variant (V1 -> V6) that stutters names the step.
The app has the same switches (Memory / Smoothness sections), so the fix can be a default change.

## RAM effectiveness (~3x target): NOT demonstrated
No honest 3x was found. Measured ceiling on the real atlas is -60% of decoded texture memory from repack+merge. Larger gains need the
script-aware resizing of backgrounds that earlier reports say is not safe to do statically. Nothing was relaxed to hit a number.
Archive size (ZIP bytes) and decoded texture memory are reported separately; game RAM is only measurable on the phone.

## New / changed files
- engine.py: independent switches `repack`, `max_dim`, `dedupe`, `fps`; reports drawn-area and options. Level defaults unchanged.
- fps_opt.py (new): the FPS part - trim switch + report of files likely to hitch (texture side > 4096, >= 64 MB decoded). Disable with fps=False.
- library.py (new): read-only mod discovery, configurable roots, status (original / has _opt copy / optimized), clear errors per root.
- replace.py (new): optimize -> independent validation -> stage -> back up original to Downloads (copy+verify when rename fails) -> place `<name>_opt`;
  rollback on failure; never overwrites (numbered names on collision). Reports optimization, validation and replacement separately.
- bridge.py: run (options), discover, run_replace.
- Theme.kt, Ui.kt (new), MainActivity.kt (rewritten around the old flow; manual mode kept), assets/themes.json, AndroidManifest.xml (configChanges so
  theme/rotation changes do not restart a running task).
- tests: test_fps, test_replace, test_themes (all 120 theme combinations checked for WCAG contrast), test_bridge additions.
- tools/bisect_variants.py (new), previous_versions/0.5.3/ (new).

## Behaviour you should know
- Folder mods become a folder `<name>_opt`; ZIP mods become `<name>_opt.zip` (a switch forces ZIP). The game treats the new name as a different mod:
  enable it in the mods menu; Lua that hard-codes the old folder name may break. Not checked in-game.
- Replacement needs "All files access". Without it only manual mode works (new ZIP into a folder you pick); replacement through the Storage Access
  Framework was NOT implemented.
- Default scan root is only `/storage/emulated/0/.PsychEngine/mods`; add others in "Mod folders".

## NOT verified here
- The Kotlin code (no Kotlin compiler/Android SDK/network here). Only bracket balance was checked. Expect to fix compile errors on the first
  GitHub Actions build; send me the log.
- Any UI appearance on a real screen, day/night switching, dialogs, the mod list, permission flows.
- Anything in-game: RAM, FPS, frame pacing, animation correctness (atlas rendering IS checked offline, pixel-exact, in tests).
