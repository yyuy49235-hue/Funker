"""Build variants of ONE mod so the FPS problem can be pinned on a single step.

    python tools/bisect_variants.py MOD_FOLDER OUT_FOLDER

Install each ZIP/folder as its own mod, play the SAME song on each (phone restarted, same settings),
and note the FPS in the first minute and near the end. The first variant that stutters names the step.
Python only needs Pillow (pip install Pillow); in Termux: pkg install python-pillow.
"""
import os, sys, time
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "app", "src", "main", "python"))
from funkerlitelab import engine

VARIANTS = [
    ("V1_lossless_only",        dict(strength="light")),
    ("V2_repack_only",          dict(strength="light", repack=True, max_dim=None, dedupe=False, fps=False)),
    ("V3_repack_trim",          dict(strength="light", repack=True, max_dim=None, dedupe=False, fps=True)),
    ("V4_repack_trim_dedupe",   dict(strength="light", repack=True, max_dim=None, dedupe=True, fps=True)),
    ("V5_resize_only",          dict(strength="light", repack=False, max_dim=1024)),
    ("V6_maximum_like_0.5.3",   dict(strength="maximum")),
]

if __name__ == "__main__":
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    os.makedirs(sys.argv[2], exist_ok=True)
    print("%-26s %-6s %12s %12s %9s %9s" % ("variant", "ok", "tex before", "tex after", "tex cut", "draw cut"))
    for name, kw in VARIANTS:
        t = time.time()
        r = engine.optimize_mod(sys.argv[1], os.path.join(sys.argv[2], name + ".zip"), **kw)
        tb, ta = r.get("texture_bytes_before", 0), r.get("texture_bytes_after", 0)
        f = r.get("fps", {})
        print("%-26s %-6s %9.1f MB %9.1f MB %8.0f%% %8s  (%.0fs)" % (
            name, r["ok"], tb / 1048576.0, ta / 1048576.0, 100.0 * (tb - ta) / tb if tb else 0,
            ("%.0f%%" % f["drawn_area_cut_percent"]) if f.get("enabled") else "off", time.time() - t))
