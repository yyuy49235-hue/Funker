# Funker Lite Lab (0.6.0)
Android app (Kotlin + Chaquopy/Python 3.11) that makes FNF / Psych Engine mods lighter.
- Engine: `app/src/main/python/funkerlitelab/engine.py` (tests: `python run_tests.py`)
- Build: GitHub Actions `Build APK` -> artifact `FunkerLiteLab-debug-apk` (APK + BUILT_FROM_COMMIT.txt)
